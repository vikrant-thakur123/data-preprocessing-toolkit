"""
Utility functions for the data analysis system.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')


def detect_data_types(data: pd.DataFrame) -> Dict[str, List[str]]:
    """
    Detect and categorize columns by their data types.
    
    Args:
        data (pd.DataFrame): Input dataset
        
    Returns:
        Dict[str, List[str]]: Categorized column names
    """
    numeric_columns = data.select_dtypes(include=[np.number]).columns.tolist()
    categorical_columns = data.select_dtypes(include=['object', 'category']).columns.tolist()
    datetime_columns = data.select_dtypes(include=['datetime64']).columns.tolist()
    boolean_columns = data.select_dtypes(include=['bool']).columns.tolist()
    
    return {
        'numeric': numeric_columns,
        'categorical': categorical_columns,
        'datetime': datetime_columns,
        'boolean': boolean_columns
    }


def calculate_missing_percentage(data: pd.DataFrame) -> float:
    """
    Calculate the percentage of missing values in the dataset.
    
    Args:
        data (pd.DataFrame): Input dataset
        
    Returns:
        float: Missing percentage
    """
    total_cells = data.size
    missing_cells = data.isnull().sum().sum()
    return (missing_cells / total_cells) * 100


def detect_constant_columns(data: pd.DataFrame) -> List[str]:
    """
    Detect columns with constant values.
    
    Args:
        data (pd.DataFrame): Input dataset
        
    Returns:
        List[str]: List of constant column names
    """
    constant_columns = []
    for col in data.columns:
        if data[col].nunique() <= 1:
            constant_columns.append(col)
    return constant_columns


def detect_high_cardinality_columns(data: pd.DataFrame, threshold: float = 0.5) -> List[str]:
    """
    Detect columns with high cardinality.
    
    Args:
        data (pd.DataFrame): Input dataset
        threshold (float): Threshold for high cardinality (as percentage of total rows)
        
    Returns:
        List[str]: List of high cardinality column names
    """
    high_cardinality_columns = []
    threshold_count = int(len(data) * threshold)
    
    for col in data.columns:
        if data[col].nunique() > threshold_count:
            high_cardinality_columns.append(col)
    
    return high_cardinality_columns


def detect_potential_id_columns(data: pd.DataFrame) -> List[str]:
    """
    Detect columns that might be ID columns.
    
    Args:
        data (pd.DataFrame): Input dataset
        
    Returns:
        List[str]: List of potential ID column names
    """
    potential_id_columns = []
    
    for col in data.columns:
        # Check if column has unique values for all rows and is string type
        if (data[col].nunique() == len(data) and 
            data[col].dtype == 'object' and
            not data[col].isnull().any()):
            potential_id_columns.append(col)
    
    return potential_id_columns


def calculate_entropy(data: pd.Series) -> float:
    """
    Calculate entropy for categorical data.
    
    Args:
        data (pd.Series): Input series
        
    Returns:
        float: Entropy value
    """
    value_counts = data.value_counts()
    probabilities = value_counts / len(data)
    entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))
    return entropy


def detect_outliers_iqr(data: pd.Series) -> Tuple[np.ndarray, Dict[str, float]]:
    """
    Detect outliers using IQR method.
    
    Args:
        data (pd.Series): Input series
        
    Returns:
        Tuple[np.ndarray, Dict[str, float]]: Outlier indices and bounds
    """
    Q1 = data.quantile(0.25)
    Q3 = data.quantile(0.75)
    IQR = Q3 - Q1
    
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    
    outliers = (data < lower_bound) | (data > upper_bound)
    
    bounds = {
        'Q1': Q1,
        'Q3': Q3,
        'IQR': IQR,
        'lower_bound': lower_bound,
        'upper_bound': upper_bound
    }
    
    return outliers, bounds


def detect_outliers_zscore(data: pd.Series, threshold: float = 3.0) -> np.ndarray:
    """
    Detect outliers using Z-score method.
    
    Args:
        data (pd.Series): Input series
        threshold (float): Z-score threshold
        
    Returns:
        np.ndarray: Boolean array indicating outliers
    """
    z_scores = np.abs((data - data.mean()) / data.std())
    return z_scores > threshold


def detect_outliers_modified_zscore(data: pd.Series, threshold: float = 3.5) -> np.ndarray:
    """
    Detect outliers using modified Z-score method.
    
    Args:
        data (pd.Series): Input series
        threshold (float): Modified Z-score threshold
        
    Returns:
        np.ndarray: Boolean array indicating outliers
    """
    median = data.median()
    mad = np.median(np.abs(data - median))
    modified_z_scores = 0.6745 * (data - median) / mad
    return np.abs(modified_z_scores) > threshold


def calculate_correlation_strength(corr_matrix: pd.DataFrame) -> List[Dict[str, Any]]:
    """
    Calculate correlation strength between variables.
    
    Args:
        corr_matrix (pd.DataFrame): Correlation matrix
        
    Returns:
        List[Dict[str, Any]]: List of correlation pairs with strength
    """
    correlations = []
    
    for i in range(len(corr_matrix.columns)):
        for j in range(i+1, len(corr_matrix.columns)):
            corr_val = corr_matrix.iloc[i, j]
            if not np.isnan(corr_val):
                strength = "weak"
                if abs(corr_val) > 0.7:
                    strength = "strong"
                elif abs(corr_val) > 0.3:
                    strength = "moderate"
                
                correlations.append({
                    'var1': corr_matrix.columns[i],
                    'var2': corr_matrix.columns[j],
                    'correlation': corr_val,
                    'strength': strength
                })
    
    return sorted(correlations, key=lambda x: abs(x['correlation']), reverse=True)


def calculate_data_quality_score(data: pd.DataFrame) -> Tuple[int, List[str]]:
    """
    Calculate overall data quality score.
    
    Args:
        data (pd.DataFrame): Input dataset
        
    Returns:
        Tuple[int, List[str]]: Quality score (0-100) and list of issues
    """
    issues = []
    score = 100
    
    # Check for missing values
    missing_pct = calculate_missing_percentage(data)
    if missing_pct > 50:
        issues.append(f"High missing data percentage: {missing_pct:.1f}%")
        score -= 30
    elif missing_pct > 20:
        issues.append(f"Moderate missing data percentage: {missing_pct:.1f}%")
        score -= 15
    elif missing_pct > 0:
        issues.append(f"Low missing data percentage: {missing_pct:.1f}%")
        score -= 5
    
    # Check for constant columns
    constant_cols = detect_constant_columns(data)
    if constant_cols:
        issues.append(f"Constant columns found: {constant_cols}")
        score -= 10
    
    # Check for high cardinality columns
    high_card_cols = detect_high_cardinality_columns(data)
    if high_card_cols:
        issues.append(f"High cardinality columns found: {high_card_cols}")
        score -= 10
    
    # Check for potential ID columns
    id_cols = detect_potential_id_columns(data)
    if id_cols:
        issues.append(f"Potential ID columns found: {id_cols}")
        score -= 5
    
    # Check for duplicate rows
    duplicate_pct = (data.duplicated().sum() / len(data)) * 100
    if duplicate_pct > 10:
        issues.append(f"High duplicate percentage: {duplicate_pct:.1f}%")
        score -= 15
    elif duplicate_pct > 0:
        issues.append(f"Low duplicate percentage: {duplicate_pct:.1f}%")
        score -= 5
    
    return max(0, score), issues


def format_number(value: float, decimals: int = 2) -> str:
    """
    Format number with appropriate precision.
    
    Args:
        value (float): Number to format
        decimals (int): Number of decimal places
        
    Returns:
        str: Formatted number string
    """
    if abs(value) >= 1e6:
        return f"{value/1e6:.{decimals}f}M"
    elif abs(value) >= 1e3:
        return f"{value/1e3:.{decimals}f}K"
    else:
        return f"{value:.{decimals}f}"


def get_memory_usage(data: pd.DataFrame) -> Dict[str, Any]:
    """
    Get detailed memory usage information.
    
    Args:
        data (pd.DataFrame): Input dataset
        
    Returns:
        Dict[str, Any]: Memory usage details
    """
    memory_usage = data.memory_usage(deep=True)
    
    return {
        'total_memory': memory_usage.sum(),
        'total_memory_mb': memory_usage.sum() / 1024**2,
        'per_column': memory_usage.to_dict(),
        'largest_column': memory_usage.idxmax(),
        'smallest_column': memory_usage.idxmin()
    }


def validate_data_consistency(data: pd.DataFrame) -> List[str]:
    """
    Validate data consistency and identify potential issues.
    
    Args:
        data (pd.DataFrame): Input dataset
        
    Returns:
        List[str]: List of consistency issues
    """
    issues = []
    
    # Check for mixed data types in columns
    for col in data.columns:
        if data[col].dtype == 'object':
            # Check if numeric values are stored as strings
            try:
                pd.to_numeric(data[col], errors='raise')
                issues.append(f"Column '{col}' contains numeric data stored as strings")
            except (ValueError, TypeError):
                pass
    
    # Check for inconsistent date formats
    datetime_cols = data.select_dtypes(include=['datetime64']).columns
    for col in datetime_cols:
        if data[col].isnull().any():
            issues.append(f"Column '{col}' has missing datetime values")
    
    # Check for negative values in columns that shouldn't have them
    numeric_cols = data.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        if 'age' in col.lower() and (data[col] < 0).any():
            issues.append(f"Column '{col}' contains negative age values")
        elif 'price' in col.lower() and (data[col] < 0).any():
            issues.append(f"Column '{col}' contains negative price values")
    
    return issues


def suggest_preprocessing_steps(data: pd.DataFrame) -> List[str]:
    """
    Suggest preprocessing steps based on data characteristics.
    
    Args:
        data (pd.DataFrame): Input dataset
        
    Returns:
        List[str]: List of suggested preprocessing steps
    """
    suggestions = []
    
    # Check missing values
    missing_pct = calculate_missing_percentage(data)
    if missing_pct > 0:
        if missing_pct > 50:
            suggestions.append("Consider dropping columns with >50% missing values")
        elif missing_pct > 20:
            suggestions.append("Use advanced imputation techniques (KNN, iterative)")
        else:
            suggestions.append("Use simple imputation (mean, median, mode)")
    
    # Check categorical columns
    categorical_cols = data.select_dtypes(include=['object', 'category']).columns
    for col in categorical_cols:
        unique_count = data[col].nunique()
        if unique_count > 50:
            suggestions.append(f"Consider grouping or encoding high cardinality column '{col}'")
        elif unique_count <= 10:
            suggestions.append(f"Use one-hot encoding for low cardinality column '{col}'")
    
    # Check numeric columns
    numeric_cols = data.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) > 1:
        # Check for different scales
        scales = []
        for col in numeric_cols:
            if data[col].std() > 0:
                scales.append(data[col].std())
        
        if scales and max(scales) / min(scales) > 100:
            suggestions.append("Apply scaling/normalization due to different scales")
    
    # Check for outliers
    outlier_cols = []
    for col in numeric_cols:
        outliers, _ = detect_outliers_iqr(data[col])
        if outliers.sum() > len(data) * 0.05:  # More than 5% outliers
            outlier_cols.append(col)
    
    if outlier_cols:
        suggestions.append(f"Consider outlier treatment for columns: {outlier_cols}")
    
    # Check for high dimensionality
    if len(data.columns) > 20:
        suggestions.append("Consider feature selection or dimensionality reduction")
    
    return suggestions


def create_data_summary(data: pd.DataFrame) -> Dict[str, Any]:
    """
    Create comprehensive data summary.
    
    Args:
        data (pd.DataFrame): Input dataset
        
    Returns:
        Dict[str, Any]: Comprehensive data summary
    """
    column_types = detect_data_types(data)
    missing_pct = calculate_missing_percentage(data)
    quality_score, quality_issues = calculate_data_quality_score(data)
    memory_info = get_memory_usage(data)
    consistency_issues = validate_data_consistency(data)
    preprocessing_suggestions = suggest_preprocessing_steps(data)
    
    return {
        'basic_info': {
            'shape': data.shape,
            'columns': list(data.columns),
            'dtypes': data.dtypes.to_dict(),
            'memory_usage_mb': memory_info['total_memory_mb']
        },
        'data_types': column_types,
        'missing_data': {
            'percentage': missing_pct,
            'by_column': data.isnull().sum().to_dict()
        },
        'data_quality': {
            'score': quality_score,
            'issues': quality_issues,
            'consistency_issues': consistency_issues
        },
        'preprocessing_suggestions': preprocessing_suggestions,
        'statistics': {
            'numeric': data.describe().to_dict() if len(column_types['numeric']) > 0 else {},
            'categorical': {
                col: {
                    'unique_count': data[col].nunique(),
                    'most_frequent': data[col].mode().iloc[0] if not data[col].mode().empty else None,
                    'entropy': calculate_entropy(data[col])
                } for col in column_types['categorical']
            }
        }
    }

