"""
Quick start script to demonstrate the data analysis system.
"""

import pandas as pd
import numpy as np
import os
import tempfile
from datetime import datetime

# Import custom modules
from data_loader import DataLoader
from data_analyzer import DataAnalyzer
from preprocessing import DataPreprocessor
from visualizations import DataVisualizer
from report_generator import ReportGenerator
from sample_data_generator import generate_sample_dataset


def quick_demo():
    """Run a quick demonstration of the system."""
    print("🚀 Automated Data Analysis & Preprocessing System - Quick Demo")
    print("=" * 70)
    
    # Step 1: Generate sample data
    print("\n📊 Step 1: Generating sample dataset...")
    data = generate_sample_dataset(
        n_samples=1000,
        missing_percentage=0.15,
        outlier_percentage=0.05
    )
    print(f"✅ Generated dataset with {data.shape[0]:,} rows and {data.shape[1]} columns")
    
    # Step 2: Analyze data
    print("\n🔍 Step 2: Running comprehensive analysis...")
    analyzer = DataAnalyzer()
    analysis_results = analyzer.analyze(data)
    
    # Display key insights
    insights = analyzer.get_summary_insights()
    print("📈 Key Insights:")
    for insight in insights:
        print(f"  • {insight}")
    
    # Step 3: Preprocess data
    print("\n⚙️ Step 3: Running preprocessing pipeline...")
    preprocessor = DataPreprocessor()
    processed_data = preprocessor.preprocess(
        data,
        missing_value_strategy='auto',
        encoding_strategy='auto',
        scaling_strategy='standard',
        feature_selection=True,
        dimensionality_reduction=False
    )
    
    print(f"✅ Preprocessing completed. Shape changed from {data.shape} to {processed_data.shape}")
    
    # Step 4: Generate visualizations
    print("\n📈 Step 4: Generating visualizations...")
    visualizer = DataVisualizer()
    
    # Create plots
    plots = {}
    plots.update(visualizer.create_overview_plots(data, analysis_results))
    plots.update(visualizer.create_distribution_plots(data, analysis_results))
    plots.update(visualizer.create_correlation_plots(data, analysis_results))
    plots.update(visualizer.create_outlier_plots(data, analysis_results))
    plots.update(visualizer.create_preprocessing_plots(data, processed_data))
    
    print(f"✅ Generated {len(plots)} visualization plots")
    
    # Step 5: Generate reports
    print("\n📄 Step 5: Generating comprehensive reports...")
    report_generator = ReportGenerator()
    preprocessing_summary = preprocessor.get_preprocessing_summary()
    
    # Create output directory
    output_dir = "demo_output"
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate HTML report
    html_path = os.path.join(output_dir, "analysis_report.html")
    report_generator.generate_html_report(
        data, analysis_results, preprocessing_summary, plots, html_path
    )
    print(f"✅ HTML report saved to: {html_path}")
    
    # Generate PDF report
    pdf_path = os.path.join(output_dir, "analysis_report.pdf")
    report_generator.generate_pdf_report(
        data, analysis_results, preprocessing_summary, plots, pdf_path
    )
    print(f"✅ PDF report saved to: {pdf_path}")
    
    # Save processed data
    processed_path = os.path.join(output_dir, "processed_data.csv")
    processed_data.to_csv(processed_path, index=False)
    print(f"✅ Processed data saved to: {processed_path}")
    
    # Save plots
    plots_dir = os.path.join(output_dir, "plots")
    visualizer.save_plots(plots, plots_dir)
    print(f"✅ Plots saved to: {plots_dir}/")
    
    # Step 6: Display summary
    print("\n📊 Step 6: Analysis Summary")
    print("-" * 40)
    
    # Dataset overview
    overview = analysis_results['dataset_overview']
    print(f"Original Dataset: {overview['shape'][0]:,} rows × {overview['shape'][1]} columns")
    print(f"Missing Values: {overview['missing_percentage']:.2f}%")
    print(f"Duplicate Rows: {overview['duplicate_percentage']:.2f}%")
    print(f"Memory Usage: {overview['memory_usage'] / 1024**2:.2f} MB")
    
    # Data quality
    quality = analysis_results['data_quality']
    print(f"Data Quality Score: {quality['quality_score']}/100")
    
    # Preprocessing summary
    print(f"Preprocessing Steps: {len(preprocessing_summary['steps'])}")
    print(f"Final Dataset: {processed_data.shape[0]:,} rows × {processed_data.shape[1]} columns")
    
    # Output files
    print(f"\n📁 Output Files Created:")
    print(f"  • {html_path}")
    print(f"  • {pdf_path}")
    print(f"  • {processed_path}")
    print(f"  • {plots_dir}/ (multiple plot files)")
    
    print(f"\n🎉 Demo completed successfully!")
    print(f"Check the '{output_dir}' directory for all generated files.")
    
    return {
        'data': data,
        'processed_data': processed_data,
        'analysis_results': analysis_results,
        'preprocessing_summary': preprocessing_summary,
        'plots': plots,
        'output_dir': output_dir
    }


def interactive_demo():
    """Run an interactive demonstration."""
    print("🎮 Interactive Demo - Automated Data Analysis System")
    print("=" * 60)
    
    while True:
        print("\nChoose an option:")
        print("1. Run quick demo")
        print("2. Generate sample datasets")
        print("3. Test system with custom data")
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ").strip()
        
        if choice == '1':
            quick_demo()
        elif choice == '2':
            print("\nGenerating sample datasets...")
            from sample_data_generator import save_sample_datasets
            save_sample_datasets()
        elif choice == '3':
            file_path = input("Enter path to your CSV/Excel file: ").strip()
            if os.path.exists(file_path):
                try:
                    # Load and analyze custom data
                    loader = DataLoader()
                    data = loader.load_data(file_path)
                    
                    print(f"✅ Loaded {data.shape[0]:,} rows and {data.shape[1]} columns")
                    
                    # Ask for analysis options
                    print("\nAnalysis options:")
                    analyze = input("Run analysis? (y/n): ").lower().startswith('y')
                    preprocess = input("Run preprocessing? (y/n): ").lower().startswith('y')
                    visualize = input("Generate visualizations? (y/n): ").lower().startswith('y')
                    report = input("Generate reports? (y/n): ").lower().startswith('y')
                    
                    if analyze:
                        analyzer = DataAnalyzer()
                        analysis_results = analyzer.analyze(data)
                        insights = analyzer.get_summary_insights()
                        print("\nKey Insights:")
                        for insight in insights:
                            print(f"  • {insight}")
                    
                    if preprocess:
                        preprocessor = DataPreprocessor()
                        processed_data = preprocessor.preprocess(data)
                        print(f"✅ Preprocessing completed. Shape: {processed_data.shape}")
                    
                    if visualize or report:
                        print("✅ Analysis completed. Check output files.")
                    
                except Exception as e:
                    print(f"❌ Error: {e}")
            else:
                print("❌ File not found!")
        elif choice == '4':
            print("👋 Goodbye!")
            break
        else:
            print("❌ Invalid choice. Please try again.")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == '--interactive':
        interactive_demo()
    else:
        quick_demo()

