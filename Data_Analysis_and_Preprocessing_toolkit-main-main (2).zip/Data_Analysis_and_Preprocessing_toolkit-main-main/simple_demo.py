"""
Simple demonstration of the data analysis system without HTML report generation.
"""

import pandas as pd
import numpy as np
import os
import tempfile
from datetime import datetime

# Import custom modules
from data_loader import DataLoader
from data_analyzer import DataAnalyzer
from preprocessing import DataPreprocessor
from visualizations import DataVisualizer
from sample_data_generator import generate_sample_dataset


def simple_demo():
    """Run a simple demonstration of the system."""
    print("🚀 Automated Data Analysis & Preprocessing System - Simple Demo")
    print("=" * 70)
    
    # Step 1: Generate sample data
    print("\n📊 Step 1: Generating sample dataset...")
    data = generate_sample_dataset(
        n_samples=500,
        missing_percentage=0.1,
        outlier_percentage=0.03
    )
    print(f"✅ Generated dataset with {data.shape[0]:,} rows and {data.shape[1]} columns")
    
    # Step 2: Analyze data
    print("\n🔍 Step 2: Running comprehensive analysis...")
    analyzer = DataAnalyzer()
    analysis_results = analyzer.analyze(data)
    
    # Display key insights
    insights = analyzer.get_summary_insights()
    print("📈 Key Insights:")
    for insight in insights:
        print(f"  • {insight}")
    
    # Step 3: Preprocess data
    print("\n⚙️ Step 3: Running preprocessing pipeline...")
    preprocessor = DataPreprocessor()
    processed_data = preprocessor.preprocess(
        data,
        missing_value_strategy='auto',
        encoding_strategy='auto',
        scaling_strategy='standard',
        feature_selection=True,
        dimensionality_reduction=False
    )
    
    print(f"✅ Preprocessing completed. Shape changed from {data.shape} to {processed_data.shape}")
    
    # Step 4: Generate visualizations
    print("\n📈 Step 4: Generating visualizations...")
    visualizer = DataVisualizer()
    
    # Create plots
    plots = {}
    plots.update(visualizer.create_overview_plots(data, analysis_results))
    plots.update(visualizer.create_distribution_plots(data, analysis_results))
    plots.update(visualizer.create_correlation_plots(data, analysis_results))
    plots.update(visualizer.create_outlier_plots(data, analysis_results))
    plots.update(visualizer.create_preprocessing_plots(data, processed_data))
    
    print(f"✅ Generated {len(plots)} visualization plots")
    
    # Step 5: Save outputs
    print("\n💾 Step 5: Saving outputs...")
    output_dir = "demo_output"
    os.makedirs(output_dir, exist_ok=True)
    
    # Save processed data
    processed_path = os.path.join(output_dir, "processed_data.csv")
    processed_data.to_csv(processed_path, index=False)
    print(f"✅ Processed data saved to: {processed_path}")
    
    # Save plots
    plots_dir = os.path.join(output_dir, "plots")
    visualizer.save_plots(plots, plots_dir)
    print(f"✅ Plots saved to: {plots_dir}/")
    
    # Step 6: Display summary
    print("\n📊 Step 6: Analysis Summary")
    print("-" * 40)
    
    # Dataset overview
    overview = analysis_results['dataset_overview']
    print(f"Original Dataset: {overview['shape'][0]:,} rows × {overview['shape'][1]} columns")
    print(f"Missing Values: {overview['missing_percentage']:.2f}%")
    print(f"Duplicate Rows: {overview['duplicate_percentage']:.2f}%")
    print(f"Memory Usage: {overview['memory_usage'] / 1024**2:.2f} MB")
    
    # Data quality
    quality = analysis_results['data_quality']
    print(f"Data Quality Score: {quality['quality_score']}/100")
    
    # Preprocessing summary
    preprocessing_summary = preprocessor.get_preprocessing_summary()
    print(f"Preprocessing Steps: {len(preprocessing_summary['steps'])}")
    print(f"Final Dataset: {processed_data.shape[0]:,} rows × {processed_data.shape[1]} columns")
    
    # Show preprocessing steps
    print("\n🔧 Applied Preprocessing Steps:")
    for i, step in enumerate(preprocessing_summary['steps'], 1):
        print(f"  {i}. {step}")
    
    # Show data quality issues
    if quality['issues']:
        print("\n⚠️ Data Quality Issues:")
        for issue in quality['issues']:
            print(f"  • {issue}")
    else:
        print("\n✅ No data quality issues detected")
    
    # Show outlier information
    total_outliers = sum(
        col_outliers['iqr_outliers']['count'] 
        for col_outliers in analysis_results['outliers'].values()
    )
    if total_outliers > 0:
        print(f"\n🔍 Outliers detected: {total_outliers} total")
    else:
        print("\n✅ No outliers detected")
    
    # Output files
    print(f"\n📁 Output Files Created:")
    print(f"  • {processed_path}")
    print(f"  • {plots_dir}/ (multiple plot files)")
    
    print(f"\n🎉 Demo completed successfully!")
    print(f"Check the '{output_dir}' directory for all generated files.")
    
    return {
        'data': data,
        'processed_data': processed_data,
        'analysis_results': analysis_results,
        'preprocessing_summary': preprocessing_summary,
        'plots': plots,
        'output_dir': output_dir
    }


if __name__ == "__main__":
    simple_demo()

