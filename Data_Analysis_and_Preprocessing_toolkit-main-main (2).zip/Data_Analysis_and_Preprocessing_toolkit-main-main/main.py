"""
Main Streamlit application for automated data analysis and preprocessing.
"""

import streamlit as st
import pandas as pd
import numpy as np
import os
import tempfile
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Import custom modules
from data_loader import DataLoader
from data_analyzer import DataAnalyzer
from preprocessing import DataPreprocessor
from visualizations import DataVisualizer
from report_generator import ReportGenerator
from simple_report_generator import SimpleReportGenerator
from ml_focused_eda import MLFocusedEDA

# Page configuration
st.set_page_config(
    page_title="Automated Data Analysis & Preprocessing",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Light, bold, dynamic UI styling (keeps bright theme)
st.markdown("""
<style>
    :root {
        --primary: #2563eb; /* blue-600 */
        --primary-700: #1d4ed8;
        --accent: #10b981;  /* emerald-500 */
        --warning: #f59e0b; /* amber-500 */
        --error: #ef4444;   /* red-500 */
        --info: #0ea5e9;    /* sky-500 */
        --bg: #ffffff;
        --surface: #f8fafc; /* slate-50 */
        --border: #e2e8f0;  /* slate-200 */
        --text: #0f172a;    /* slate-900 */
        --muted: #475569;   /* slate-600 */
        --shadow: 0 6px 18px rgba(37, 99, 235, 0.15);
        --shadow-soft: 0 4px 14px rgba(15, 23, 42, 0.08);
    }

    .stApp {
        background: var(--bg);
        color: var(--text);
    }

    .main-header {
        font-size: 3rem;
        font-weight: 800;
        letter-spacing: -0.5px;
        text-align: center;
        margin-bottom: 1.5rem;
        background: linear-gradient(90deg, var(--primary), var(--accent));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    /* Divider */
    .block-container > div > hr {
        border: none;
        height: 2px;
        background: linear-gradient(90deg, var(--primary), transparent);
        opacity: 0.3;
        margin: 0.75rem 0 1.25rem 0;
    }

    /* Metric cards */
    .metric-card, .stMetric {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 14px !important;
        padding: 1rem !important;
        box-shadow: var(--shadow-soft);
    }

    /* Buttons */
    .stButton > button {
        background: linear-gradient(90deg, var(--primary), var(--primary-700));
        color: #fff;
        border: none;
        border-radius: 10px;
        padding: 0.6rem 1.1rem;
        font-weight: 700;
        letter-spacing: 0.3px;
        box-shadow: var(--shadow);
        transition: transform 0.15s ease, box-shadow 0.15s ease, filter 0.15s ease;
    }
    .stButton > button:hover { transform: translateY(-1px); filter: brightness(1.02); }
    .stButton > button:active { transform: translateY(0); filter: brightness(0.98); }

    /* Inputs */
    .stSelectbox div[data-baseweb="select"],
    .stTextInput input,
    .stNumberInput input,
    .stFileUploader div[role="button"],
    .stMultiSelect div[data-baseweb="select"],
    .stDateInput input {
        background: #fff !important;
        border: 1px solid var(--border) !important;
        border-radius: 10px !important;
        color: var(--text) !important;
        box-shadow: inset 0 1px 2px rgba(15,23,42,0.04);
    }

    /* Tabs */
    .stTabs [data-baseweb="tab-list"] {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 6px;
        box-shadow: var(--shadow-soft);
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 10px;
        font-weight: 700;
        color: var(--muted);
    }
    .stTabs [aria-selected="true"] {
        background: linear-gradient(90deg, rgba(37,99,235,0.12), rgba(16,185,129,0.12));
        color: var(--text);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-soft);
    }

    /* Dataframes */
    .dataframe, .stDataFrame {
        background: #fff;
        border: 1px solid var(--border);
        border-radius: 12px;
        box-shadow: var(--shadow-soft);
    }

    /* Status messages */
    .success-message { border: 1px solid rgba(16,185,129,0.25); background: rgba(16,185,129,0.08); border-radius: 10px; }
    .warning-message { border: 1px solid rgba(245,158,11,0.25); background: rgba(245,158,11,0.08); border-radius: 10px; }
    .error-message   { border: 1px solid rgba(239,68,68,0.25);  background: rgba(239,68,68,0.08);  border-radius: 10px; }
    .info-message    { border: 1px solid rgba(14,165,233,0.25); background: rgba(14,165,233,0.08); border-radius: 10px; }

    /* Progress bar */
    .stProgress > div > div > div > div {
        background: linear-gradient(90deg, var(--primary), var(--accent));
    }

    /* Uploader */
    .stFileUploader > div {
        border: 2px dashed var(--border) !important;
        background: var(--surface);
        border-radius: 12px;
    }

    /* Expanders */
    .streamlit-expanderHeader { font-weight: 700; }

    /* Subheaders */
    h2, h3, h4 { color: var(--text); font-weight: 800; letter-spacing: -0.2px; }

    /* Section cards helper */
    .section-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 14px;
        padding: 1rem 1.25rem;
        box-shadow: var(--shadow-soft);
        margin: 0.5rem 0 1rem 0;
    }
</style>
""", unsafe_allow_html=True)


def main():
    """Main application function."""
    
    # Header
    st.markdown('<h1 class="main-header">📊 Automated Data Analysis & Preprocessing</h1>', unsafe_allow_html=True)
    st.markdown("---")
    
    # Initialize session state
    if 'data_loaded' not in st.session_state:
        st.session_state.data_loaded = False
    if 'analysis_complete' not in st.session_state:
        st.session_state.analysis_complete = False
    if 'preprocessing_complete' not in st.session_state:
        st.session_state.preprocessing_complete = False
    
    # Sidebar
    with st.sidebar:
        st.header("🔧 Configuration")
        
        # File upload
        st.subheader("📁 Upload Dataset")
        uploaded_file = st.file_uploader(
            "Choose a CSV or Excel file",
            type=['csv', 'xlsx', 'xls'],
            help="Upload your dataset for analysis"
        )
        
        if uploaded_file is not None:
            # Save uploaded file temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix=f".{uploaded_file.name.split('.')[-1]}") as tmp_file:
                tmp_file.write(uploaded_file.getvalue())
                tmp_file_path = tmp_file.name
            
            # Load data
            try:
                loader = DataLoader()
                data = loader.load_data(tmp_file_path)
                st.session_state.data = data
                st.session_state.data_loaded = True
                st.session_state.file_name = uploaded_file.name
                
                st.success(f"✅ Successfully loaded {data.shape[0]:,} rows and {data.shape[1]} columns")
                
                # Display basic info
                st.subheader("📋 Dataset Info")
                st.write(f"**File:** {uploaded_file.name}")
                st.write(f"**Shape:** {data.shape[0]:,} rows × {data.shape[1]} columns")
                st.write(f"**Memory:** {data.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
                
            except Exception as e:
                st.error(f"❌ Error loading file: {str(e)}")
                st.session_state.data_loaded = False
        
        # Analysis configuration
        if st.session_state.data_loaded:
            st.subheader("🔍 Analysis Settings")
            
            # Preprocessing options
            st.subheader("⚙️ Preprocessing Options")
            
            # Missing value strategy selection
            missing_strategy = st.selectbox(
                "Missing Value Strategy",
                ["auto", "manual", "drop", "fill_mean", "fill_median", "interpolate", "knn"],
                help="Choose how to handle missing values. Select 'manual' for column-specific settings."
            )
            
            # Manual imputation settings
            manual_imputation_settings = {}
            if missing_strategy == "manual":
                st.markdown("### 🔧 Manual Imputation Settings")
                st.info("Configure imputation method for each column with missing values")
                
                # Get columns with missing values
                missing_cols = st.session_state.data.columns[st.session_state.data.isnull().any()].tolist()
                
                if missing_cols:
                    for col in missing_cols:
                        col_type = st.session_state.data[col].dtype
                        missing_count = st.session_state.data[col].isnull().sum()
                        missing_pct = (missing_count / len(st.session_state.data)) * 100
                        
                        st.markdown(f"**{col}** ({col_type}) - {missing_count} missing ({missing_pct:.1f}%)")
                        
                        if col_type in ['int64', 'float64']:
                            # Numeric column options
                            imputation_method = st.selectbox(
                                f"Imputation method for {col}",
                                ["mean", "median", "mode", "interpolate", "knn", "drop_column", "custom_value"],
                                key=f"impute_{col}",
                                help=f"Choose how to handle missing values in {col}"
                            )
                            
                            if imputation_method == "custom_value":
                                custom_value = st.number_input(
                                    f"Custom value for {col}",
                                    value=0.0,
                                    key=f"custom_{col}",
                                    help="Enter a custom value to fill missing data"
                                )
                                manual_imputation_settings[col] = {
                                    'method': 'custom',
                                    'value': custom_value
                                }
                            else:
                                manual_imputation_settings[col] = {
                                    'method': imputation_method
                                }
                        else:
                            # Categorical column options
                            imputation_method = st.selectbox(
                                f"Imputation method for {col}",
                                ["mode", "drop_column", "custom_value"],
                                key=f"impute_{col}",
                                help=f"Choose how to handle missing values in {col}"
                            )
                            
                            if imputation_method == "custom_value":
                                custom_value = st.text_input(
                                    f"Custom value for {col}",
                                    value="Unknown",
                                    key=f"custom_{col}",
                                    help="Enter a custom value to fill missing data"
                                )
                                manual_imputation_settings[col] = {
                                    'method': 'custom',
                                    'value': custom_value
                                }
                            else:
                                manual_imputation_settings[col] = {
                                    'method': imputation_method
                                }
                else:
                    st.success("✅ No missing values found in the dataset!")
            else:
                # Store the selected strategy for non-manual options
                st.session_state.missing_strategy = missing_strategy
            
            # Store manual settings in session state
            if missing_strategy == "manual":
                st.session_state.manual_imputation_settings = manual_imputation_settings
                st.session_state.missing_strategy = "manual"
            
            encoding_strategy = st.selectbox(
                "Categorical Encoding",
                ["auto", "one_hot", "label", "ordinal"],
                help="Choose encoding strategy for categorical variables"
            )
            
            scaling_strategy = st.selectbox(
                "Scaling Strategy",
                ["standard", "minmax", "robust", "none"],
                help="Choose scaling method for numerical variables"
            )
            
            feature_selection = st.checkbox(
                "Enable Feature Selection",
                value=True,
                help="Automatically select most relevant features"
            )
            
            dimensionality_reduction = st.checkbox(
                "Enable Dimensionality Reduction",
                value=False,
                help="Apply PCA for dimensionality reduction"
            )
            
            # Target column selection
            target_column = None
            if feature_selection or dimensionality_reduction:
                numeric_cols = st.session_state.data.select_dtypes(include=[np.number]).columns.tolist()
                if numeric_cols:
                    target_column = st.selectbox(
                        "Target Column (for supervised methods)",
                        ["None"] + numeric_cols,
                        help="Select target column for supervised feature selection"
                    )
                    if target_column == "None":
                        target_column = None
    
    # Main content area
    if not st.session_state.data_loaded:
        st.markdown("""
        ## Welcome to the Automated Data Analysis & Preprocessing System! 🚀
        
        This application provides comprehensive data analysis and preprocessing capabilities:
        
        ### ✨ Features:
        - **Data Upload**: Support for CSV and Excel files
        - **Automated Analysis**: Detailed insights including statistics, correlations, distributions, missing values, and outliers
        - **Preprocessing Pipeline**: 
          - Missing value handling (drop, fill, interpolation)
          - Categorical encoding (label, one-hot, ordinal)
          - Scaling and normalization
          - Feature selection and dimensionality reduction
        - **Visualizations**: Interactive charts and plots
        - **Report Generation**: Comprehensive HTML and PDF reports
        - **Export**: Processed data ready for ML pipelines
        
        ### 🚀 Getting Started:
        1. Upload your dataset using the sidebar
        2. Configure analysis and preprocessing options
        3. Run the analysis to get insights
        4. Download processed data and reports
        
        **Upload a file to begin!** 📁
        """)
        
        # Sample data option
        st.markdown("---")
        st.subheader("🎯 Try with Sample Data")
        
        if st.button("Generate Sample Dataset", help="Create a sample dataset for testing"):
            # Generate sample data
            np.random.seed(42)
            n_samples = 1000
            
            sample_data = pd.DataFrame({
                'age': np.random.normal(35, 10, n_samples),
                'income': np.random.normal(50000, 15000, n_samples),
                'education': np.random.choice(['High School', 'Bachelor', 'Master', 'PhD'], n_samples),
                'experience': np.random.normal(8, 5, n_samples),
                'score': np.random.normal(75, 15, n_samples),
                'category': np.random.choice(['A', 'B', 'C', 'D'], n_samples),
                'rating': np.random.uniform(1, 5, n_samples)
            })
            
            # Add some missing values
            missing_indices = np.random.choice(n_samples, size=int(n_samples * 0.1), replace=False)
            sample_data.loc[missing_indices, 'income'] = np.nan
            
            # Add some outliers
            outlier_indices = np.random.choice(n_samples, size=int(n_samples * 0.05), replace=False)
            sample_data.loc[outlier_indices, 'age'] = np.random.normal(80, 5, len(outlier_indices))
            
            st.session_state.data = sample_data
            st.session_state.data_loaded = True
            st.session_state.file_name = "sample_dataset.csv"
            
            st.success("✅ Sample dataset generated successfully!")
            st.rerun()
    
    else:
        # Data loaded - show analysis options
        data = st.session_state.data
        
        # Tabs for different sections
        tab1, tab2, tab3, tab4, tab5 = st.tabs(["📊 Data Overview", "🔍 Analysis", "⚙️ Preprocessing", "📈 Visualizations", "📄 Reports"])
        
        with tab1:
            st.header("📊 Dataset Overview")
            
            # Basic statistics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Rows", f"{data.shape[0]:,}")
            with col2:
                st.metric("Columns", data.shape[1])
            with col3:
                missing_pct = (data.isnull().sum().sum() / data.size) * 100
                st.metric("Missing %", f"{missing_pct:.2f}%")
            with col4:
                memory_mb = data.memory_usage(deep=True).sum() / 1024**2
                st.metric("Memory", f"{memory_mb:.2f} MB")
            
            # Data types
            st.subheader("📋 Data Types")
            dtype_counts = data.dtypes.value_counts()
            col1, col2 = st.columns(2)
            
            with col1:
                st.bar_chart(dtype_counts)
            
            with col2:
                st.dataframe(pd.DataFrame({
                    'Data Type': dtype_counts.index,
                    'Count': dtype_counts.values
                }))
            
            # Sample data
            st.subheader("👀 Sample Data")
            st.dataframe(data.head(10))
            
            # Missing values
            if data.isnull().any().any():
                st.subheader("❌ Missing Values")
                missing_data = data.isnull().sum()
                missing_data = missing_data[missing_data > 0].sort_values(ascending=False)
                
                col1, col2 = st.columns(2)
                with col1:
                    st.bar_chart(missing_data)
                with col2:
                    st.dataframe(pd.DataFrame({
                        'Column': missing_data.index,
                        'Missing Count': missing_data.values,
                        'Missing %': (missing_data.values / len(data)) * 100
                    }))
        
        with tab2:
            st.header("🔍 Data Analysis")
            
            if st.button("🚀 Run Analysis", type="primary"):
                with st.spinner("Running comprehensive analysis..."):
                    try:
                        # Initialize analyzer
                        analyzer = DataAnalyzer()
                        
                        # Run analysis
                        analysis_results = analyzer.analyze(data)
                        st.session_state.analysis_results = analysis_results
                        st.session_state.analyzer = analyzer  # Store analyzer in session state
                        st.session_state.analysis_complete = True
                        
                        st.success("✅ Analysis completed successfully!")
                        
                    except Exception as e:
                        st.error(f"❌ Error during analysis: {str(e)}")
            
            if st.session_state.analysis_complete:
                analysis_results = st.session_state.analysis_results
                analyzer = st.session_state.analyzer  # Get analyzer from session state
                
                # Display insights
                st.subheader("💡 Key Insights")
                insights = analyzer.get_summary_insights()
                for insight in insights:
                    st.info(f"💡 {insight}")
                
                # Dataset overview
                st.subheader("📊 Dataset Overview")
                overview = analysis_results['dataset_overview']
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Total Cells", f"{overview['total_cells']:,}")
                    st.metric("Missing Cells", f"{overview['missing_cells']:,}")
                    st.metric("Duplicate Rows", f"{overview['duplicate_rows']:,}")
                
                with col2:
                    st.metric("Memory Usage", f"{overview['memory_usage'] / 1024**2:.2f} MB")
                    st.metric("Missing %", f"{overview['missing_percentage']:.2f}%")
                    st.metric("Duplicate %", f"{overview['duplicate_percentage']:.2f}%")
                
                # Data quality
                st.subheader("🎯 Data Quality Assessment")
                quality = analysis_results['data_quality']
                
                col1, col2 = st.columns([1, 2])
                with col1:
                    st.metric("Quality Score", f"{quality['quality_score']}/100")
                
                with col2:
                    if quality['issues']:
                        st.warning("⚠️ Quality Issues Found:")
                        for issue in quality['issues']:
                            st.write(f"• {issue}")
                    else:
                        st.success("✅ No quality issues detected")
                
                # Descriptive statistics
                st.subheader("📈 Descriptive Statistics")
                if 'numeric' in analysis_results['descriptive_statistics']:
                    numeric_stats = analysis_results['descriptive_statistics']['numeric']
                    stats_df = pd.DataFrame(numeric_stats)
                    st.dataframe(stats_df.round(2))
                
                # Outliers
                st.subheader("🔍 Outlier Detection")
                outliers = analysis_results['outliers']
                total_outliers = sum(
                    col_outliers['iqr_outliers']['count'] 
                    for col_outliers in outliers.values()
                )
                
                if total_outliers > 0:
                    st.warning(f"⚠️ {total_outliers} outliers detected across all numeric columns")
                    
                    # Show outlier details
                    outlier_df = []
                    for col, col_outliers in outliers.items():
                        outlier_df.append({
                            'Column': col,
                            'IQR Outliers': col_outliers['iqr_outliers']['count'],
                            'Z-Score Outliers': col_outliers['z_score_outliers']['count'],
                            'Modified Z-Score Outliers': col_outliers['modified_z_outliers']['count']
                        })
                    
                    st.dataframe(pd.DataFrame(outlier_df))
                else:
                    st.success("✅ No outliers detected")
        
        with tab3:
            st.header("⚙️ Data Preprocessing")
            
            if st.button("🔧 Run Preprocessing", type="primary"):
                with st.spinner("Running preprocessing pipeline..."):
                    try:
                        # Get preprocessing parameters from sidebar
                        missing_strategy = st.session_state.get('missing_strategy', 'auto')
                        encoding_strategy = st.session_state.get('encoding_strategy', 'auto')
                        scaling_strategy = st.session_state.get('scaling_strategy', 'standard')
                        feature_selection = st.session_state.get('feature_selection', True)
                        dimensionality_reduction = st.session_state.get('dimensionality_reduction', False)
                        target_column = st.session_state.get('target_column', None)
                        
                        # Initialize preprocessor
                        preprocessor = DataPreprocessor()
                        
                        # Get manual imputation settings if available
                        manual_settings = st.session_state.get('manual_imputation_settings', None)
                        
                        # Run preprocessing
                        processed_data = preprocessor.preprocess(
                            data,
                            missing_value_strategy=missing_strategy,
                            encoding_strategy=encoding_strategy,
                            scaling_strategy=scaling_strategy,
                            feature_selection=feature_selection,
                            dimensionality_reduction=dimensionality_reduction,
                            target_column=target_column,
                            manual_imputation_settings=manual_settings
                        )
                        
                        st.session_state.processed_data = processed_data
                        st.session_state.preprocessing_summary = preprocessor.get_preprocessing_summary()
                        st.session_state.preprocessing_complete = True
                        
                        st.success("✅ Preprocessing completed successfully!")
                        
                    except Exception as e:
                        st.error(f"❌ Error during preprocessing: {str(e)}")
            
            if st.session_state.preprocessing_complete:
                processed_data = st.session_state.processed_data
                preprocessing_summary = st.session_state.preprocessing_summary
                
                # Show preprocessing summary
                st.subheader("📋 Preprocessing Summary")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Original Shape", f"{preprocessing_summary['original_shape'][0]:,} × {preprocessing_summary['original_shape'][1]}")
                    st.metric("Processed Shape", f"{preprocessing_summary['processed_shape'][0]:,} × {preprocessing_summary['processed_shape'][1]}")
                
                with col2:
                    st.metric("Transformations Applied", len(preprocessing_summary['steps']))
                    st.metric("Encoders Used", len(preprocessing_summary['encoders_applied']))
                
                # Show preprocessing steps
                st.subheader("🔧 Applied Transformations")
                for i, step in enumerate(preprocessing_summary['steps'], 1):
                    st.write(f"{i}. {step}")
                
                # Show manual imputation settings if used
                if st.session_state.get('missing_strategy') == 'manual' and st.session_state.get('manual_imputation_settings'):
                    st.subheader("🎯 Manual Imputation Settings")
                    manual_settings = st.session_state.manual_imputation_settings
                    for col, settings in manual_settings.items():
                        method = settings['method']
                        if method == 'custom':
                            st.write(f"**{col}**: Custom value = {settings['value']}")
                        else:
                            st.write(f"**{col}**: {method.title()}")
                
                # Show processed data
                st.subheader("📊 Processed Data Preview")
                st.dataframe(processed_data.head(10))
                
                # Download processed data
                st.subheader("💾 Download Processed Data")
                csv = processed_data.to_csv(index=False)
                st.download_button(
                    label="📥 Download CSV",
                    data=csv,
                    file_name=f"processed_{st.session_state.file_name}",
                    mime="text/csv"
                )
        
        with tab4:
            st.header("🤖 ML-Focused EDA Analysis")
            
            # Analysis type selection
            analysis_type = st.radio(
                "Choose Analysis Type:",
                ["🎯 ML-Focused EDA", "📊 Comprehensive EDA"],
                help="ML-Focused EDA provides streamlined analysis optimized for machine learning insights"
            )
            
            if st.button("🚀 Generate Analysis", type="primary"):
                with st.spinner("Generating analysis..."):
                    try:
                        if analysis_type == "🎯 ML-Focused EDA":
                            # ML-Focused EDA
                            ml_eda = MLFocusedEDA()
                            
                            if st.session_state.analysis_complete:
                                analysis_results = st.session_state.analysis_results
                                plots = ml_eda.create_ml_eda_plots(data, analysis_results)
                                
                                # Generate ML insights
                                ml_insights = ml_eda.generate_ml_insights(data, analysis_results)
                                
                                st.session_state.plots = plots
                                st.session_state.ml_insights = ml_insights
                                st.session_state.analysis_type = "ml_focused"
                                
                                st.success("✅ ML-Focused EDA completed successfully!")
                            else:
                                st.warning("⚠️ Please run data analysis first!")
                                
                        else:
                            # Comprehensive EDA
                            visualizer = DataVisualizer()
                            
                            if st.session_state.analysis_complete:
                                analysis_results = st.session_state.analysis_results
                                plots = {}
                                
                                # Overview plots
                                overview_plots = visualizer.create_overview_plots(data, analysis_results)
                                plots.update(overview_plots)
                                
                                # Distribution plots
                                dist_plots = visualizer.create_distribution_plots(data, analysis_results)
                                plots.update(dist_plots)
                                
                                # Correlation plots
                                corr_plots = visualizer.create_correlation_plots(data, analysis_results)
                                plots.update(corr_plots)
                                
                                # Outlier plots
                                outlier_plots = visualizer.create_outlier_plots(data, analysis_results)
                                plots.update(outlier_plots)
                                
                                # Preprocessing plots
                                if st.session_state.preprocessing_complete:
                                    processed_data = st.session_state.processed_data
                                    prep_plots = visualizer.create_preprocessing_plots(data, processed_data)
                                    plots.update(prep_plots)
                                
                                st.session_state.plots = plots
                                st.session_state.analysis_type = "comprehensive"
                                st.success("✅ Comprehensive EDA completed successfully!")
                            else:
                                st.warning("⚠️ Please run data analysis first!")
                            
                    except Exception as e:
                        st.error(f"❌ Error generating analysis: {str(e)}")
            
            # Display ML insights if available
            if 'ml_insights' in st.session_state and st.session_state.get('analysis_type') == 'ml_focused':
                st.subheader("🎯 ML Insights & Recommendations")
                for insight in st.session_state.ml_insights:
                    st.info(insight)
                st.markdown("---")
            
            # Display plots
            if 'plots' in st.session_state:
                plots = st.session_state.plots
                
                if st.session_state.get('analysis_type') == 'ml_focused':
                    st.subheader("🤖 ML-Focused Analysis Plots")
                else:
                    st.subheader("📊 Comprehensive Analysis Plots")
                
                # Display plots
                for plot_name, plot_fig in plots.items():
                    if plot_fig is not None:
                        st.subheader(f"📊 {plot_name.replace('_', ' ').title()}")
                        st.pyplot(plot_fig)
                        st.markdown("---")
        
        with tab5:
            st.header("📄 Reports")
            
            if st.button("📋 Generate Reports", type="primary"):
                with st.spinner("Generating comprehensive reports..."):
                    try:
                        # Initialize robust report generator (Jinja2-based)
                        report_generator = ReportGenerator()
                        
                        # Generate HTML report
                        if st.session_state.analysis_complete and 'plots' in st.session_state:
                            analysis_results = st.session_state.analysis_results
                            preprocessing_summary = st.session_state.get('preprocessing_summary', {})
                            plots = st.session_state.plots
                            
                            # Generate HTML report
                            html_path = report_generator.generate_html_report(
                                data, analysis_results, preprocessing_summary, plots
                            )
                            
                            st.session_state.html_report = html_path
                            
                            st.success("✅ Report generated successfully!")
                            
                        else:
                            st.warning("⚠️ Please run analysis and generate visualizations first!")
                            
                    except Exception as e:
                        st.error(f"❌ Error generating reports: {str(e)}")
                        st.error(f"Details: {str(e)}")
            
            if 'html_report' in st.session_state:
                st.subheader("📥 Download Report")
                
                # HTML report download
                with open(st.session_state.html_report, 'rb') as f:
                    html_data = f.read()
                
                st.download_button(
                    label="📄 Download HTML Report",
                    data=html_data,
                    file_name="analysis_report.html",
                    mime="text/html",
                    help="Download the complete analysis report as an HTML file"
                )
                
                # Preview HTML report
                st.subheader("👀 Report Preview")
                with open(st.session_state.html_report, 'r', encoding='utf-8') as f:
                    html_content = f.read()
                st.components.v1.html(html_content, height=600, scrolling=True)

if __name__ == "__main__":
    main()

