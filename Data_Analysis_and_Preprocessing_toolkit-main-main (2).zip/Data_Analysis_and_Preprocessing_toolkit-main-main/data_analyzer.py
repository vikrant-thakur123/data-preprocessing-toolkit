"""
Core data analysis module with comprehensive insights generation.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_regression, f_classif
import warnings
warnings.filterwarnings('ignore')


class DataAnalyzer:
    """Comprehensive data analysis and insights generation."""
    
    def __init__(self):
        self.data = None
        self.analysis_results = {}
        self.column_types = {}
        self.outliers = {}
        
    def analyze(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Perform comprehensive data analysis.
        
        Args:
            data (pd.DataFrame): Input dataset
            
        Returns:
            Dict[str, Any]: Analysis results
        """
        self.data = data.copy()
        self.column_types = self._categorize_columns()
        
        analysis_results = {
            'dataset_overview': self._get_dataset_overview(),
            'descriptive_statistics': self._get_descriptive_statistics(),
            'correlations': self._get_correlations(),
            'distributions': self._analyze_distributions(),
            'missing_values': self._analyze_missing_values(),
            'outliers': self._detect_outliers(),
            'data_quality': self._assess_data_quality(),
            'column_analysis': self._analyze_columns()
        }
        
        self.analysis_results = analysis_results
        return analysis_results
    
    def _categorize_columns(self) -> Dict[str, List[str]]:
        """Categorize columns by data type."""
        numeric_columns = self.data.select_dtypes(include=[np.number]).columns.tolist()
        categorical_columns = self.data.select_dtypes(include=['object', 'category']).columns.tolist()
        datetime_columns = self.data.select_dtypes(include=['datetime64']).columns.tolist()
        boolean_columns = self.data.select_dtypes(include=['bool']).columns.tolist()
        
        return {
            'numeric': numeric_columns,
            'categorical': categorical_columns,
            'datetime': datetime_columns,
            'boolean': boolean_columns
        }
    
    def _get_dataset_overview(self) -> Dict[str, Any]:
        """Get basic dataset overview."""
        return {
            'shape': self.data.shape,
            'memory_usage': self.data.memory_usage(deep=True).sum(),
            'total_cells': self.data.size,
            'missing_cells': self.data.isnull().sum().sum(),
            'missing_percentage': (self.data.isnull().sum().sum() / self.data.size) * 100,
            'duplicate_rows': self.data.duplicated().sum(),
            'duplicate_percentage': (self.data.duplicated().sum() / len(self.data)) * 100,
            'column_types': {k: len(v) for k, v in self.column_types.items()}
        }
    
    def _get_descriptive_statistics(self) -> Dict[str, Any]:
        """Get comprehensive descriptive statistics."""
        stats_dict = {}
        
        # Numeric columns statistics
        if self.column_types['numeric']:
            numeric_data = self.data[self.column_types['numeric']]
            stats_dict['numeric'] = {
                'count': numeric_data.count().to_dict(),
                'mean': numeric_data.mean().to_dict(),
                'std': numeric_data.std().to_dict(),
                'min': numeric_data.min().to_dict(),
                'max': numeric_data.max().to_dict(),
                'median': numeric_data.median().to_dict(),
                'q25': numeric_data.quantile(0.25).to_dict(),
                'q75': numeric_data.quantile(0.75).to_dict(),
                'skewness': numeric_data.skew().to_dict(),
                'kurtosis': numeric_data.kurtosis().to_dict()
            }
        
        # Categorical columns statistics
        if self.column_types['categorical']:
            categorical_data = self.data[self.column_types['categorical']]
            stats_dict['categorical'] = {}
            for col in categorical_data.columns:
                value_counts = categorical_data[col].value_counts()
                stats_dict['categorical'][col] = {
                    'unique_count': categorical_data[col].nunique(),
                    'most_frequent': value_counts.index[0] if len(value_counts) > 0 else None,
                    'most_frequent_count': value_counts.iloc[0] if len(value_counts) > 0 else 0,
                    'most_frequent_percentage': (value_counts.iloc[0] / len(categorical_data)) * 100 if len(value_counts) > 0 else 0,
                    'top_5_values': value_counts.head(5).to_dict()
                }
        
        return stats_dict
    
    def _get_correlations(self) -> Dict[str, Any]:
        """Calculate correlation matrices."""
        correlations = {}
        
        # Numeric correlations
        if len(self.column_types['numeric']) > 1:
            numeric_data = self.data[self.column_types['numeric']]
            correlations['numeric_pearson'] = numeric_data.corr(method='pearson').to_dict()
            correlations['numeric_spearman'] = numeric_data.corr(method='spearman').to_dict()
            
            # High correlations
            corr_matrix = numeric_data.corr()
            high_corr_pairs = []
            for i in range(len(corr_matrix.columns)):
                for j in range(i+1, len(corr_matrix.columns)):
                    corr_val = corr_matrix.iloc[i, j]
                    if abs(corr_val) > 0.7:  # High correlation threshold
                        high_corr_pairs.append({
                            'var1': corr_matrix.columns[i],
                            'var2': corr_matrix.columns[j],
                            'correlation': corr_val
                        })
            correlations['high_correlations'] = high_corr_pairs
        
        return correlations
    
    def _analyze_distributions(self) -> Dict[str, Any]:
        """Analyze data distributions."""
        distributions = {}
        
        for col in self.column_types['numeric']:
            data_col = self.data[col].dropna()
            if len(data_col) > 0:
                # Normality tests
                shapiro_stat, shapiro_p = stats.shapiro(data_col) if len(data_col) <= 5000 else (None, None)
                ks_stat, ks_p = stats.kstest(data_col, 'norm', args=(data_col.mean(), data_col.std()))
                
                distributions[col] = {
                    'is_normal_shapiro': shapiro_p > 0.05 if shapiro_p is not None else None,
                    'is_normal_ks': ks_p > 0.05,
                    'skewness': stats.skew(data_col),
                    'kurtosis': stats.kurtosis(data_col),
                    'distribution_type': self._classify_distribution(data_col)
                }
        
        return distributions
    
    def _classify_distribution(self, data: pd.Series) -> str:
        """Classify the type of distribution."""
        skewness = stats.skew(data)
        kurtosis = stats.kurtosis(data)
        
        if abs(skewness) < 0.5 and abs(kurtosis) < 0.5:
            return "Normal"
        elif skewness > 0.5:
            return "Right-skewed"
        elif skewness < -0.5:
            return "Left-skewed"
        elif kurtosis > 0.5:
            return "Heavy-tailed"
        elif kurtosis < -0.5:
            return "Light-tailed"
        else:
            return "Unknown"
    
    def _analyze_missing_values(self) -> Dict[str, Any]:
        """Analyze missing value patterns."""
        missing_analysis = {}
        
        # Overall missing data
        missing_analysis['overall'] = {
            'total_missing': self.data.isnull().sum().sum(),
            'missing_percentage': (self.data.isnull().sum().sum() / self.data.size) * 100,
            'columns_with_missing': self.data.columns[self.data.isnull().any()].tolist()
        }
        
        # Per-column missing analysis
        missing_analysis['by_column'] = {}
        for col in self.data.columns:
            missing_count = self.data[col].isnull().sum()
            missing_analysis['by_column'][col] = {
                'count': missing_count,
                'percentage': (missing_count / len(self.data)) * 100,
                'data_type': str(self.data[col].dtype)
            }
        
        # Missing data patterns
        missing_analysis['patterns'] = self._analyze_missing_patterns()
        
        return missing_analysis
    
    def _analyze_missing_patterns(self) -> Dict[str, Any]:
        """Analyze patterns in missing data."""
        missing_data = self.data.isnull()
        
        # Complete cases
        complete_cases = missing_data.sum(axis=1) == 0
        complete_cases_count = complete_cases.sum()
        
        # Missing data patterns
        missing_patterns = {}
        for threshold in [0.1, 0.25, 0.5, 0.75, 0.9]:
            pattern = missing_data.sum(axis=1) / len(missing_data.columns) >= threshold
            missing_patterns[f'missing_{int(threshold*100)}%_or_more'] = pattern.sum()
        
        return {
            'complete_cases': complete_cases_count,
            'complete_cases_percentage': (complete_cases_count / len(self.data)) * 100,
            'missing_patterns': missing_patterns
        }
    
    def _detect_outliers(self) -> Dict[str, Any]:
        """Detect outliers using multiple methods."""
        outliers = {}
        
        for col in self.column_types['numeric']:
            data_col = self.data[col].dropna()
            if len(data_col) > 0:
                outliers[col] = self._detect_column_outliers(data_col, col)
        
        self.outliers = outliers
        return outliers
    
    def _detect_column_outliers(self, data: pd.Series, col_name: str) -> Dict[str, Any]:
        """Detect outliers for a single column."""
        outliers_info = {}
        
        # IQR method
        Q1 = data.quantile(0.25)
        Q3 = data.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        iqr_outliers = data[(data < lower_bound) | (data > upper_bound)]
        
        # Z-score method
        z_scores = np.abs(stats.zscore(data))
        z_outliers = data[z_scores > 3]
        
        # Modified Z-score method
        median = data.median()
        mad = np.median(np.abs(data - median))
        modified_z_scores = 0.6745 * (data - median) / mad
        modified_z_outliers = data[np.abs(modified_z_scores) > 3.5]
        
        outliers_info = {
            'iqr_outliers': {
                'count': len(iqr_outliers),
                'percentage': (len(iqr_outliers) / len(data)) * 100,
                'indices': iqr_outliers.index.tolist()
            },
            'z_score_outliers': {
                'count': len(z_outliers),
                'percentage': (len(z_outliers) / len(data)) * 100,
                'indices': z_outliers.index.tolist()
            },
            'modified_z_outliers': {
                'count': len(modified_z_outliers),
                'percentage': (len(modified_z_outliers) / len(data)) * 100,
                'indices': modified_z_outliers.index.tolist()
            }
        }
        
        return outliers_info
    
    def _assess_data_quality(self) -> Dict[str, Any]:
        """Assess overall data quality."""
        quality_issues = []
        
        # Check for constant columns
        constant_columns = [col for col in self.data.columns if self.data[col].nunique() <= 1]
        if constant_columns:
            quality_issues.append(f"Constant columns: {constant_columns}")
        
        # Check for high cardinality categorical columns
        high_cardinality = []
        for col in self.column_types['categorical']:
            if self.data[col].nunique() > len(self.data) * 0.5:
                high_cardinality.append(col)
        if high_cardinality:
            quality_issues.append(f"High cardinality categorical columns: {high_cardinality}")
        
        # Check for potential ID columns
        potential_id_columns = []
        for col in self.data.columns:
            if self.data[col].nunique() == len(self.data) and self.data[col].dtype == 'object':
                potential_id_columns.append(col)
        if potential_id_columns:
            quality_issues.append(f"Potential ID columns: {potential_id_columns}")
        
        return {
            'issues': quality_issues,
            'constant_columns': constant_columns,
            'high_cardinality_columns': high_cardinality,
            'potential_id_columns': potential_id_columns,
            'quality_score': max(0, 100 - len(quality_issues) * 10)  # Simple quality score
        }
    
    def _analyze_columns(self) -> Dict[str, Any]:
        """Detailed analysis of each column."""
        column_analysis = {}
        
        for col in self.data.columns:
            col_data = self.data[col]
            analysis = {
                'dtype': str(col_data.dtype),
                'non_null_count': col_data.count(),
                'null_count': col_data.isnull().sum(),
                'unique_count': col_data.nunique(),
                'memory_usage': col_data.memory_usage(deep=True)
            }
            
            if col in self.column_types['numeric']:
                analysis.update({
                    'mean': col_data.mean(),
                    'std': col_data.std(),
                    'min': col_data.min(),
                    'max': col_data.max(),
                    'has_outliers': col in self.outliers and any(
                        self.outliers[col][method]['count'] > 0 
                        for method in ['iqr_outliers', 'z_score_outliers', 'modified_z_outliers']
                    )
                })
            elif col in self.column_types['categorical']:
                value_counts = col_data.value_counts()
                analysis.update({
                    'most_frequent': value_counts.index[0] if len(value_counts) > 0 else None,
                    'most_frequent_count': value_counts.iloc[0] if len(value_counts) > 0 else 0,
                    'entropy': self._calculate_entropy(col_data)
                })
            
            column_analysis[col] = analysis
        
        return column_analysis
    
    def _calculate_entropy(self, data: pd.Series) -> float:
        """Calculate entropy for categorical data."""
        value_counts = data.value_counts()
        probabilities = value_counts / len(data)
        entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))
        return entropy
    
    def get_summary_insights(self) -> List[str]:
        """Generate summary insights from the analysis."""
        insights = []
        
        if not self.analysis_results:
            return ["No analysis performed yet."]
        
        # Dataset overview insights
        overview = self.analysis_results['dataset_overview']
        insights.append(f"Dataset contains {overview['shape'][0]:,} rows and {overview['shape'][1]} columns")
        insights.append(f"Missing data: {overview['missing_percentage']:.2f}% of all cells")
        
        if overview['duplicate_percentage'] > 0:
            insights.append(f"Duplicate rows: {overview['duplicate_percentage']:.2f}%")
        
        # Data quality insights
        quality = self.analysis_results['data_quality']
        if quality['issues']:
            insights.append(f"Data quality issues found: {len(quality['issues'])}")
        
        # Outlier insights
        total_outliers = 0
        for col_outliers in self.analysis_results['outliers'].values():
            total_outliers += col_outliers['iqr_outliers']['count']
        
        if total_outliers > 0:
            insights.append(f"Total outliers detected: {total_outliers}")
        
        # Correlation insights
        if 'high_correlations' in self.analysis_results['correlations']:
            high_corr = self.analysis_results['correlations']['high_correlations']
            if high_corr:
                insights.append(f"High correlations found: {len(high_corr)} pairs")
        
        return insights

