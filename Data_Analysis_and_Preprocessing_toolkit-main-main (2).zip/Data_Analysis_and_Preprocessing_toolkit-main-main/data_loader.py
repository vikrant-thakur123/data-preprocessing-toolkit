"""
Data loading utilities for CSV and Excel files.
"""

import pandas as pd
import numpy as np
from typing import Union, Optional, Tuple
import os


class DataLoader:
    """Handles loading of CSV and Excel files with error handling and validation."""
    
    def __init__(self):
        self.data = None
        self.file_path = None
        self.file_type = None
        
    def load_data(self, file_path: str, **kwargs) -> pd.DataFrame:
        """
        Load data from CSV or Excel file.
        
        Args:
            file_path (str): Path to the data file
            **kwargs: Additional arguments for pandas read functions
            
        Returns:
            pd.DataFrame: Loaded dataset
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is not supported
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
            
        self.file_path = file_path
        file_extension = os.path.splitext(file_path)[1].lower()
        
        try:
            if file_extension == '.csv':
                self.data = pd.read_csv(file_path, **kwargs)
                self.file_type = 'csv'
            elif file_extension in ['.xlsx', '.xls']:
                self.data = pd.read_excel(file_path, **kwargs)
                self.file_type = 'excel'
            else:
                raise ValueError(f"Unsupported file format: {file_extension}")
                
            print(f"Successfully loaded {self.data.shape[0]} rows and {self.data.shape[1]} columns")
            return self.data
            
        except Exception as e:
            raise Exception(f"Error loading file: {str(e)}")
    
    def get_data_info(self) -> dict:
        """
        Get basic information about the loaded dataset.
        
        Returns:
            dict: Dataset information
        """
        if self.data is None:
            raise ValueError("No data loaded. Call load_data() first.")
            
        return {
            'shape': self.data.shape,
            'columns': list(self.data.columns),
            'dtypes': self.data.dtypes.to_dict(),
            'memory_usage': self.data.memory_usage(deep=True).sum(),
            'file_type': self.file_type,
            'file_path': self.file_path
        }
    
    def validate_data(self) -> dict:
        """
        Validate the loaded dataset for common issues.
        
        Returns:
            dict: Validation results
        """
        if self.data is None:
            raise ValueError("No data loaded. Call load_data() first.")
            
        validation_results = {
            'has_duplicates': self.data.duplicated().any(),
            'duplicate_count': self.data.duplicated().sum(),
            'has_null_values': self.data.isnull().any().any(),
            'null_counts': self.data.isnull().sum().to_dict(),
            'empty_columns': self.data.columns[self.data.isnull().all()].tolist(),
            'constant_columns': [col for col in self.data.columns if self.data[col].nunique() <= 1],
            'high_cardinality_columns': [col for col in self.data.columns 
                                       if self.data[col].dtype == 'object' and self.data[col].nunique() > 100]
        }
        
        return validation_results
    
    def get_column_types(self) -> dict:
        """
        Categorize columns by data type.
        
        Returns:
            dict: Column categorization
        """
        if self.data is None:
            raise ValueError("No data loaded. Call load_data() first.")
            
        numeric_columns = self.data.select_dtypes(include=[np.number]).columns.tolist()
        categorical_columns = self.data.select_dtypes(include=['object', 'category']).columns.tolist()
        datetime_columns = self.data.select_dtypes(include=['datetime64']).columns.tolist()
        boolean_columns = self.data.select_dtypes(include=['bool']).columns.tolist()
        
        return {
            'numeric': numeric_columns,
            'categorical': categorical_columns,
            'datetime': datetime_columns,
            'boolean': boolean_columns
        }
    
    def sample_data(self, n: int = 5) -> pd.DataFrame:
        """
        Get a sample of the data.
        
        Args:
            n (int): Number of rows to sample
            
        Returns:
            pd.DataFrame: Sample data
        """
        if self.data is None:
            raise ValueError("No data loaded. Call load_data() first.")
            
        return self.data.sample(n=min(n, len(self.data)))
    
    def get_missing_data_summary(self) -> pd.DataFrame:
        """
        Get detailed missing data summary.
        
        Returns:
            pd.DataFrame: Missing data summary
        """
        if self.data is None:
            raise ValueError("No data loaded. Call load_data() first.")
            
        missing_data = pd.DataFrame({
            'Column': self.data.columns,
            'Missing_Count': self.data.isnull().sum(),
            'Missing_Percentage': (self.data.isnull().sum() / len(self.data)) * 100,
            'Data_Type': self.data.dtypes
        })
        
        return missing_data.sort_values('Missing_Percentage', ascending=False)

