"""
Sample data generator for testing the data analysis system.
"""

import pandas as pd
import numpy as np
from typing import Optional, Tuple
import os


def generate_sample_dataset(n_samples: int = 1000, 
                          n_features: int = 10,
                          missing_percentage: float = 0.1,
                          outlier_percentage: float = 0.05,
                          random_state: int = 42) -> pd.DataFrame:
    """
    Generate a sample dataset for testing the data analysis system.
    
    Args:
        n_samples (int): Number of samples
        n_features (int): Number of features
        missing_percentage (float): Percentage of missing values
        outlier_percentage (float): Percentage of outliers
        random_state (int): Random seed
        
    Returns:
        pd.DataFrame: Generated sample dataset
    """
    np.random.seed(random_state)
    
    # Generate numeric features
    data = {}
    
    # Age (normal distribution)
    data['age'] = np.random.normal(35, 10, n_samples)
    data['age'] = np.clip(data['age'], 18, 80)  # Clip to realistic range
    
    # Income (log-normal distribution)
    data['income'] = np.random.lognormal(10, 0.5, n_samples)
    data['income'] = np.clip(data['income'], 20000, 200000)
    
    # Education level (categorical)
    education_levels = ['High School', 'Bachelor', 'Master', 'PhD']
    data['education'] = np.random.choice(education_levels, n_samples, 
                                       p=[0.3, 0.4, 0.2, 0.1])
    
    # Experience (correlated with age)
    data['experience'] = data['age'] - 22 + np.random.normal(0, 3, n_samples)
    data['experience'] = np.clip(data['experience'], 0, 50)
    
    # Score (correlated with education and experience)
    base_score = 50
    education_bonus = np.where(data['education'] == 'PhD', 20,
                              np.where(data['education'] == 'Master', 15,
                                      np.where(data['education'] == 'Bachelor', 10, 0)))
    experience_bonus = data['experience'] * 0.5
    data['score'] = base_score + education_bonus + experience_bonus + np.random.normal(0, 10, n_samples)
    data['score'] = np.clip(data['score'], 0, 100)
    
    # Category (categorical with some correlation)
    categories = ['A', 'B', 'C', 'D']
    category_probs = [0.4, 0.3, 0.2, 0.1]
    data['category'] = np.random.choice(categories, n_samples, p=category_probs)
    
    # Rating (correlated with score)
    data['rating'] = data['score'] / 20 + np.random.normal(0, 0.5, n_samples)
    data['rating'] = np.clip(data['rating'], 1, 5)
    
    # Hours per week (normal distribution)
    data['hours_per_week'] = np.random.normal(40, 10, n_samples)
    data['hours_per_week'] = np.clip(data['hours_per_week'], 10, 80)
    
    # Department (categorical)
    departments = ['Engineering', 'Sales', 'Marketing', 'HR', 'Finance']
    data['department'] = np.random.choice(departments, n_samples)
    
    # Performance (target variable - correlated with multiple features)
    performance = (data['score'] * 0.3 + 
                  data['rating'] * 0.2 + 
                  data['experience'] * 0.1 + 
                  np.random.normal(0, 5, n_samples))
    data['performance'] = performance
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Add missing values
    if missing_percentage > 0:
        n_missing = int(n_samples * missing_percentage)
        missing_indices = np.random.choice(n_samples, size=n_missing, replace=False)
        
        # Randomly assign missing values to different columns
        columns_to_missing = ['income', 'score', 'rating', 'hours_per_week']
        for idx in missing_indices:
            col = np.random.choice(columns_to_missing)
            df.loc[idx, col] = np.nan
    
    # Add outliers
    if outlier_percentage > 0:
        n_outliers = int(n_samples * outlier_percentage)
        outlier_indices = np.random.choice(n_samples, size=n_outliers, replace=False)
        
        # Add outliers to numeric columns
        numeric_cols = ['age', 'income', 'score', 'hours_per_week']
        for idx in outlier_indices:
            col = np.random.choice(numeric_cols)
            if col == 'age':
                df.loc[idx, col] = np.random.uniform(90, 100)
            elif col == 'income':
                df.loc[idx, col] = np.random.uniform(300000, 500000)
            elif col == 'score':
                df.loc[idx, col] = np.random.uniform(95, 100)
            elif col == 'hours_per_week':
                df.loc[idx, col] = np.random.uniform(90, 100)
    
    return df


def generate_time_series_dataset(n_samples: int = 1000, 
                                start_date: str = '2020-01-01',
                                random_state: int = 42) -> pd.DataFrame:
    """
    Generate a time series dataset for testing.
    
    Args:
        n_samples (int): Number of samples
        start_date (str): Start date for the time series
        random_state (int): Random seed
        
    Returns:
        pd.DataFrame: Generated time series dataset
    """
    np.random.seed(random_state)
    
    # Generate date range
    dates = pd.date_range(start=start_date, periods=n_samples, freq='D')
    
    # Generate time series data
    data = {
        'date': dates,
        'value': np.cumsum(np.random.normal(0, 1, n_samples)) + 100,
        'trend': np.linspace(100, 150, n_samples) + np.random.normal(0, 5, n_samples),
        'seasonal': 10 * np.sin(2 * np.pi * np.arange(n_samples) / 365) + np.random.normal(0, 2, n_samples),
        'noise': np.random.normal(0, 3, n_samples)
    }
    
    # Add some categorical data
    categories = ['A', 'B', 'C']
    data['category'] = np.random.choice(categories, n_samples, p=[0.5, 0.3, 0.2])
    
    # Add some missing values
    missing_indices = np.random.choice(n_samples, size=int(n_samples * 0.05), replace=False)
    data['value'][missing_indices] = np.nan
    
    return pd.DataFrame(data)


def generate_classification_dataset(n_samples: int = 1000,
                                  n_features: int = 10,
                                  n_classes: int = 3,
                                  random_state: int = 42) -> pd.DataFrame:
    """
    Generate a classification dataset for testing.
    
    Args:
        n_samples (int): Number of samples
        n_features (int): Number of features
        n_classes (int): Number of classes
        random_state (int): Random seed
        
    Returns:
        pd.DataFrame: Generated classification dataset
    """
    from sklearn.datasets import make_classification
    
    X, y = make_classification(
        n_samples=n_samples,
        n_features=n_features,
        n_classes=n_classes,
        n_clusters_per_class=1,
        random_state=random_state
    )
    
    # Create feature names
    feature_names = [f'feature_{i}' for i in range(n_features)]
    
    # Create DataFrame
    df = pd.DataFrame(X, columns=feature_names)
    df['target'] = y
    
    # Add some categorical features
    df['category'] = np.random.choice(['X', 'Y', 'Z'], n_samples)
    df['binary'] = np.random.choice([0, 1], n_samples)
    
    # Add some missing values
    missing_indices = np.random.choice(n_samples, size=int(n_samples * 0.1), replace=False)
    df.loc[missing_indices, 'feature_0'] = np.nan
    
    return df


def save_sample_datasets(output_dir: str = "sample_data"):
    """
    Generate and save sample datasets for testing.
    
    Args:
        output_dir (str): Output directory for sample datasets
    """
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate different types of datasets
    datasets = {
        'regression_data.csv': generate_sample_dataset(n_samples=1000),
        'time_series_data.csv': generate_time_series_dataset(n_samples=500),
        'classification_data.csv': generate_classification_dataset(n_samples=800)
    }
    
    # Save datasets
    for filename, df in datasets.items():
        filepath = os.path.join(output_dir, filename)
        df.to_csv(filepath, index=False)
        print(f"✅ Generated {filename} with shape {df.shape}")
    
    print(f"\n🎉 Sample datasets saved to {output_dir}/")
    print("You can use these datasets to test the analysis system!")


if __name__ == "__main__":
    # Generate sample datasets
    save_sample_datasets()
    
    # Also generate a larger dataset for comprehensive testing
    large_dataset = generate_sample_dataset(n_samples=5000, missing_percentage=0.15)
    large_dataset.to_csv("sample_data/large_dataset.csv", index=False)
    print("✅ Generated large_dataset.csv with shape", large_dataset.shape)

