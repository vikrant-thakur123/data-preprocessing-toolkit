"""
Setup script for the Automated Data Analysis and Preprocessing System.
"""

from setuptools import setup, find_packages
import os

# Read the README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="automated-data-analysis",
    version="1.0.0",
    author="Data Analysis Team",
    author_email="team@dataanalysis.com",
    description="A comprehensive Python-based system for automated data analysis and preprocessing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/automated-data-analysis",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "mypy>=1.0.0",
        ],
        "jupyter": [
            "jupyter>=1.0.0",
            "ipywidgets>=8.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "data-analyzer=cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.md", "*.txt", "*.yml", "*.yaml"],
    },
    keywords="data-analysis, preprocessing, machine-learning, pandas, scikit-learn, visualization",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/automated-data-analysis/issues",
        "Source": "https://github.com/yourusername/automated-data-analysis",
        "Documentation": "https://github.com/yourusername/automated-data-analysis#readme",
    },
)

