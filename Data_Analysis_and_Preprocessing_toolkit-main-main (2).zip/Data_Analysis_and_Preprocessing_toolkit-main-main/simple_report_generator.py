"""
Simple report generator for creating HTML reports without complex dependencies.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional
import matplotlib.pyplot as plt
import base64
from io import BytesIO
import os
from datetime import datetime


class SimpleReportGenerator:
    """Generate simple HTML reports for data analysis."""
    
    def __init__(self):
        self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def generate_html_report(self, data: pd.DataFrame, analysis_results: Dict[str, Any], 
                           preprocessing_summary: Dict[str, Any], 
                           plots: Dict[str, plt.Figure], 
                           output_path: str = "analysis_report.html") -> str:
        """Generate simple HTML report."""
        
        # Convert plots to base64 for embedding
        plot_images = self._convert_plots_to_base64(plots)
        
        # Generate HTML content
        html_content = self._generate_html_content(
            data, analysis_results, preprocessing_summary, plot_images
        )
        
        # Save HTML file
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"HTML report saved to: {output_path}")
        return output_path
    
    def _convert_plots_to_base64(self, plots: Dict[str, plt.Figure]) -> Dict[str, str]:
        """Convert matplotlib figures to base64 encoded strings."""
        plot_images = {}
        
        for name, fig in plots.items():
            if fig is not None:
                try:
                    # Save figure to bytes
                    buffer = BytesIO()
                    fig.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
                    buffer.seek(0)
                    
                    # Convert to base64
                    image_base64 = base64.b64encode(buffer.getvalue()).decode()
                    plot_images[name] = f"data:image/png;base64,{image_base64}"
                    
                    # Close figure to free memory
                    plt.close(fig)
                except Exception as e:
                    print(f"Warning: Could not convert plot {name}: {e}")
                    plot_images[name] = ""
        
        return plot_images
    
    def _generate_html_content(self, data: pd.DataFrame, analysis_results: Dict[str, Any], 
                             preprocessing_summary: Dict[str, Any], 
                             plot_images: Dict[str, str]) -> str:
        """Generate HTML content for the report."""
        
        # Prepare data for template
        overview = analysis_results['dataset_overview']
        quality = analysis_results['data_quality']
        missing_values = analysis_results['missing_values']['by_column']
        numeric_stats = analysis_results['descriptive_statistics'].get('numeric', {})
        
        # Format numeric stats properly
        if numeric_stats and 'mean' in numeric_stats:
            numeric_stats_formatted = {}
            for col in numeric_stats['mean'].keys():
                numeric_stats_formatted[col] = {
                    'mean': f"{numeric_stats['mean'][col]:.2f}",
                    'std': f"{numeric_stats['std'][col]:.2f}",
                    'min': f"{numeric_stats['min'][col]:.2f}",
                    'max': f"{numeric_stats['max'][col]:.2f}",
                    'skewness': f"{numeric_stats['skewness'][col]:.2f}"
                }
            numeric_stats = numeric_stats_formatted
        
        # Generate insights
        insights = self._generate_insights(analysis_results)
        recommendations = self._generate_recommendations(analysis_results, preprocessing_summary)
        
        html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Analysis Report</title>
    <style>
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background: linear-gradient(135deg, #0e1117 0%, #1a1a2e 100%);
            color: #ffffff;
            line-height: 1.6;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { 
            text-align: center; 
            background: linear-gradient(135deg, #00d4aa, #4ecdc4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 2rem;
        }
        .header h1 { font-size: 2.5em; margin: 0; }
        .section { 
            background: rgba(38, 39, 48, 0.8); 
            margin: 20px 0; 
            padding: 25px; 
            border-radius: 12px; 
            border: 1px solid #404040;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }
        .section h2 { 
            color: #00d4aa; 
            border-bottom: 2px solid #00d4aa; 
            padding-bottom: 10px;
            margin-top: 0;
        }
        .metric-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 15px; 
            margin: 20px 0; 
        }
        .metric-card { 
            background: linear-gradient(135deg, #262730, #2a2a3a); 
            padding: 20px; 
            border-radius: 8px; 
            border-left: 4px solid #00d4aa;
            text-align: center;
        }
        .metric-value { 
            font-size: 1.5em; 
            font-weight: bold; 
            color: #00d4aa; 
        }
        .metric-label { 
            color: #b0b0b0; 
            font-size: 0.9em; 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin: 20px 0; 
            background: rgba(38, 39, 48, 0.5);
        }
        th, td { 
            border: 1px solid #404040; 
            padding: 12px; 
            text-align: left; 
        }
        th { 
            background: linear-gradient(135deg, #00d4aa, #4ecdc4); 
            color: #000; 
            font-weight: bold; 
        }
        tr:nth-child(even) { background: rgba(64, 64, 64, 0.3); }
        .plot-container { 
            text-align: center; 
            margin: 30px 0; 
            background: rgba(38, 39, 48, 0.5);
            padding: 20px;
            border-radius: 8px;
        }
        .plot-container img { 
            max-width: 100%; 
            height: auto; 
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }
        .insight { 
            background: rgba(0, 212, 170, 0.1); 
            padding: 15px; 
            border-left: 4px solid #00d4aa; 
            margin: 15px 0; 
            border-radius: 4px;
        }
        .warning { 
            background: rgba(255, 167, 38, 0.1); 
            padding: 15px; 
            border-left: 4px solid #ffa726; 
            margin: 15px 0; 
            border-radius: 4px;
        }
        .success { 
            background: rgba(76, 175, 80, 0.1); 
            padding: 15px; 
            border-left: 4px solid #4caf50; 
            margin: 15px 0; 
            border-radius: 4px;
        }
        .timestamp { 
            text-align: center; 
            color: #b0b0b0; 
            font-size: 0.9em; 
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Data Analysis Report</h1>
            <div class="timestamp">Generated on: {self.timestamp}</div>
        </div>
        
        <div class="section">
            <h2>📈 Executive Summary</h2>
            <p>This report presents a comprehensive analysis of a dataset containing <strong>{overview['shape'][0]:,}</strong> rows and <strong>{overview['shape'][1]}</strong> columns. 
            The dataset has a data quality score of <strong>{quality['quality_score']}/100</strong> and contains <strong>{overview['missing_percentage']:.2f}%</strong> missing values.</p>
            
            <p>Key findings include the identification of <strong>{len(quality['issues'])}</strong> data quality issues and the application of <strong>{len(preprocessing_summary.get('steps', []))}</strong> preprocessing transformations.
            The analysis provides insights into data distributions, correlations, outliers, and missing value patterns to support informed decision-making.</p>
        </div>
        
        <div class="section">
            <h2>📊 Dataset Overview</h2>
            <div class="metric-grid">
                <div class="metric-card">
                    <div class="metric-value">{overview['shape'][0]:,}</div>
                    <div class="metric-label">Rows</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{overview['shape'][1]}</div>
                    <div class="metric-label">Columns</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{overview['missing_percentage']:.2f}%</div>
                    <div class="metric-label">Missing Values</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{overview['duplicate_percentage']:.2f}%</div>
                    <div class="metric-label">Duplicate Rows</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{overview['memory_usage'] / 1024**2:.2f} MB</div>
                    <div class="metric-label">Memory Usage</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{quality['quality_score']}/100</div>
                    <div class="metric-label">Quality Score</div>
                </div>
            </div>
        </div>
        
        <div class="section">
            <h2>🎯 Data Quality Assessment</h2>
            <div class="metric-card" style="text-align: left;">
                <div class="metric-value">Quality Score: {quality['quality_score']}/100</div>
            </div>
            {"".join([f'<div class="warning"><strong>⚠️ {issue}</strong></div>' for issue in quality['issues']]) if quality['issues'] else '<div class="success"><strong>✅ No significant data quality issues detected.</strong></div>'}
        </div>
        
        <div class="section">
            <h2>❌ Missing Values Analysis</h2>
            <table>
                <tr><th>Column</th><th>Missing Count</th><th>Missing %</th><th>Data Type</th></tr>
                {"".join([f'<tr><td>{col}</td><td>{info["count"]}</td><td>{info["percentage"]:.2f}%</td><td>{info["data_type"]}</td></tr>' for col, info in missing_values.items() if info['percentage'] > 0]) if any(info['percentage'] > 0 for info in missing_values.values()) else '<tr><td colspan="4">No missing values found</td></tr>'}
            </table>
        </div>
        
        <div class="section">
            <h2>📈 Descriptive Statistics</h2>
            {"".join([f'<div class="metric-card"><strong>{col}</strong><br>Mean: {stats["mean"]}, Std: {stats["std"]}, Min: {stats["min"]}, Max: {stats["max"]}</div>' for col, stats in numeric_stats.items()]) if numeric_stats else '<p>No numeric columns found.</p>'}
        </div>
        
        <div class="section">
            <h2>⚙️ Preprocessing Summary</h2>
            <h3>Applied Transformations ({len(preprocessing_summary.get('steps', []))} steps):</h3>
            <ul>
                {"".join([f'<li>{step}</li>' for step in preprocessing_summary.get('steps', [])])}
            </ul>
            
            <div class="metric-grid">
                <div class="metric-card">
                    <div class="metric-value">{preprocessing_summary.get('original_shape', (0, 0))[0]}</div>
                    <div class="metric-label">Original Rows</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{preprocessing_summary.get('original_shape', (0, 0))[1]}</div>
                    <div class="metric-label">Original Columns</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{preprocessing_summary.get('processed_shape', (0, 0))[0]}</div>
                    <div class="metric-label">Processed Rows</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{preprocessing_summary.get('processed_shape', (0, 0))[1]}</div>
                    <div class="metric-label">Processed Columns</div>
                </div>
            </div>
        </div>
        
        <div class="section">
            <h2>📊 Visualizations</h2>
            {"".join([f'<div class="plot-container"><h3>{plot_name.replace("_", " ").title()}</h3><img src="{plot_img}" alt="{plot_name}"></div>' for plot_name, plot_img in plot_images.items() if plot_img])}
        </div>
        
        <div class="section">
            <h2>💡 Key Insights</h2>
            {"".join([f'<div class="insight"><strong>💡 {insight}</strong></div>' for insight in insights])}
        </div>
        
        <div class="section">
            <h2>🎯 Recommendations</h2>
            {"".join([f'<div class="insight"><strong>🎯 {recommendation}</strong></div>' for recommendation in recommendations])}
        </div>
    </div>
</body>
</html>
        """
        
        return html_content
    
    def _generate_insights(self, analysis_results: Dict[str, Any]) -> List[str]:
        """Generate key insights from the analysis."""
        insights = []
        
        # Dataset size insights
        shape = analysis_results['dataset_overview']['shape']
        insights.append(f"Dataset contains {shape[0]:,} observations across {shape[1]} features")
        
        # Missing data insights
        missing_pct = analysis_results['dataset_overview']['missing_percentage']
        if missing_pct > 0:
            insights.append(f"Missing data affects {missing_pct:.1f}% of all cells, requiring careful handling")
        else:
            insights.append("No missing values detected in the dataset")
        
        # Data quality insights
        quality_score = analysis_results['data_quality']['quality_score']
        if quality_score >= 80:
            insights.append("High data quality score indicates reliable dataset for analysis")
        elif quality_score >= 60:
            insights.append("Moderate data quality score suggests some data cleaning may be beneficial")
        else:
            insights.append("Low data quality score indicates significant data cleaning is required")
        
        # Outlier insights
        total_outliers = sum(
            col_outliers['iqr_outliers']['count'] 
            for col_outliers in analysis_results['outliers'].values()
        )
        if total_outliers > 0:
            insights.append(f"Detected {total_outliers} potential outliers that may need attention")
        
        # Correlation insights
        if 'high_correlations' in analysis_results['correlations']:
            high_corr = analysis_results['correlations']['high_correlations']
            if high_corr:
                insights.append(f"Found {len(high_corr)} pairs of highly correlated variables")
        
        return insights
    
    def _generate_recommendations(self, analysis_results: Dict[str, Any], 
                                preprocessing_summary: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on the analysis."""
        recommendations = []
        
        # Missing data recommendations
        missing_pct = analysis_results['dataset_overview']['missing_percentage']
        if missing_pct > 20:
            recommendations.append("Consider using advanced imputation techniques for high missing data percentage")
        elif missing_pct > 0:
            recommendations.append("Standard imputation methods should be sufficient for low missing data")
        
        # Data quality recommendations
        quality_issues = analysis_results['data_quality']['issues']
        if quality_issues:
            recommendations.append("Address identified data quality issues before proceeding with analysis")
        
        # Feature selection recommendations
        numeric_cols = analysis_results['dataset_overview']['column_types']['numeric']
        if numeric_cols > 10:
            recommendations.append("Consider feature selection techniques to reduce dimensionality")
        
        # Outlier recommendations
        total_outliers = sum(
            col_outliers['iqr_outliers']['count'] 
            for col_outliers in analysis_results['outliers'].values()
        )
        if total_outliers > analysis_results['dataset_overview']['shape'][0] * 0.05:
            recommendations.append("High number of outliers detected - consider outlier treatment strategies")
        
        # Preprocessing recommendations
        if preprocessing_summary.get('steps'):
            recommendations.append("Preprocessing pipeline successfully applied - data is ready for machine learning")
        
        return recommendations