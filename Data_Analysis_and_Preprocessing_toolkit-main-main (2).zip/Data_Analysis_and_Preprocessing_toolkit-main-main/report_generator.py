"""
Report generation module for creating comprehensive analysis reports.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import base64
from io import BytesIO
import os
from jinja2 import Template
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
import warnings
warnings.filterwarnings('ignore')


class ReportGenerator:
    """Generate comprehensive analysis reports in HTML and PDF formats."""
    
    def __init__(self):
        self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom styles for the report."""
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            alignment=1,  # Center alignment
            textColor=colors.darkblue
        ))
        
        self.styles.add(ParagraphStyle(
            name='CustomHeading',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            textColor=colors.darkblue
        ))
        
        self.styles.add(ParagraphStyle(
            name='CustomSubHeading',
            parent=self.styles['Heading3'],
            fontSize=12,
            spaceAfter=8,
            textColor=colors.darkgreen
        ))
    
    def generate_html_report(self, data: pd.DataFrame, analysis_results: Dict[str, Any], 
                           preprocessing_summary: Dict[str, Any], 
                           plots: Dict[str, plt.Figure], 
                           output_path: str = "analysis_report.html") -> str:
        """Generate comprehensive HTML report."""
        
        # Convert plots to base64 for embedding
        plot_images = self._convert_plots_to_base64(plots)
        
        # Generate HTML content
        html_content = self._generate_html_content(
            data, analysis_results, preprocessing_summary, plot_images
        )
        
        # Save HTML file
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"HTML report saved to: {output_path}")
        return output_path
    
    def generate_pdf_report(self, data: pd.DataFrame, analysis_results: Dict[str, Any], 
                          preprocessing_summary: Dict[str, Any], 
                          plots: Dict[str, plt.Figure], 
                          output_path: str = "analysis_report.pdf") -> str:
        """Generate comprehensive PDF report."""
        
        doc = SimpleDocTemplate(output_path, pagesize=A4)
        story = []
        
        # Title
        title = Paragraph("Data Analysis Report", self.styles['CustomTitle'])
        story.append(title)
        story.append(Spacer(1, 12))
        
        # Timestamp
        timestamp = Paragraph(f"Generated on: {self.timestamp}", self.styles['Normal'])
        story.append(timestamp)
        story.append(Spacer(1, 20))
        
        # Executive Summary
        story.append(Paragraph("Executive Summary", self.styles['CustomHeading']))
        summary_text = self._generate_executive_summary(analysis_results, preprocessing_summary)
        story.append(Paragraph(summary_text, self.styles['Normal']))
        story.append(Spacer(1, 12))
        
        # Dataset Overview
        story.append(Paragraph("Dataset Overview", self.styles['CustomHeading']))
        overview_data = self._create_overview_table(analysis_results['dataset_overview'])
        story.append(overview_data)
        story.append(Spacer(1, 12))
        
        # Data Quality Assessment
        story.append(Paragraph("Data Quality Assessment", self.styles['CustomHeading']))
        quality_text = self._generate_quality_assessment(analysis_results['data_quality'])
        story.append(Paragraph(quality_text, self.styles['Normal']))
        story.append(Spacer(1, 12))
        
        # Missing Values Analysis
        story.append(Paragraph("Missing Values Analysis", self.styles['CustomHeading']))
        missing_data = self._create_missing_values_table(analysis_results['missing_values'])
        story.append(missing_data)
        story.append(Spacer(1, 12))
        
        # Descriptive Statistics
        story.append(Paragraph("Descriptive Statistics", self.styles['CustomHeading']))
        stats_data = self._create_statistics_table(analysis_results['descriptive_statistics'])
        story.append(stats_data)
        story.append(Spacer(1, 12))
        
        # Preprocessing Summary
        story.append(Paragraph("Preprocessing Summary", self.styles['CustomHeading']))
        preprocessing_text = self._generate_preprocessing_summary(preprocessing_summary)
        story.append(Paragraph(preprocessing_text, self.styles['Normal']))
        story.append(Spacer(1, 12))
        
        # Add plots
        for plot_name, plot_fig in plots.items():
            if plot_fig is not None:
                story.append(Paragraph(plot_name.replace('_', ' ').title(), self.styles['CustomSubHeading']))
                plot_img = self._convert_plot_to_image(plot_fig)
                if plot_img is not None:
                    story.append(plot_img)
                    story.append(Spacer(1, 12))
        
        # Build PDF
        doc.build(story)
        print(f"PDF report saved to: {output_path}")
        return output_path
    
    def _convert_plots_to_base64(self, plots: Dict[str, plt.Figure]) -> Dict[str, str]:
        """Convert matplotlib figures to base64 encoded strings."""
        plot_images = {}
        
        for name, fig in plots.items():
            if fig is not None:
                # Save figure to bytes
                buffer = BytesIO()
                fig.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
                buffer.seek(0)
                
                # Convert to base64
                image_base64 = base64.b64encode(buffer.getvalue()).decode()
                plot_images[name] = f"data:image/png;base64,{image_base64}"
                
                # Close figure to free memory
                plt.close(fig)
        
        return plot_images
    
    def _convert_plot_to_image(self, fig: plt.Figure) -> Image:
        """Convert matplotlib figure to ReportLab Image."""
        try:
            buffer = BytesIO()
            fig.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
            buffer.seek(0)
            
            # Create ReportLab Image directly from buffer
            img = Image(buffer, width=6*inch, height=4*inch)
            
            # Clean up
            buffer.close()
            plt.close(fig)
            
            return img
        except Exception as e:
            print(f"Warning: Could not convert plot to image: {e}")
            return None
    
    def _generate_html_content(self, data: pd.DataFrame, analysis_results: Dict[str, Any], 
                             preprocessing_summary: Dict[str, Any], 
                             plot_images: Dict[str, str]) -> str:
        """Generate HTML content for the report."""
        
        html_template = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Data Analysis Report</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
                .header { text-align: center; color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 20px; }
                .section { margin: 30px 0; }
                .subsection { margin: 20px 0; }
                h1 { color: #2c3e50; font-size: 2.5em; margin-bottom: 10px; }
                h2 { color: #34495e; font-size: 1.8em; margin-top: 30px; border-left: 4px solid #3498db; padding-left: 15px; }
                h3 { color: #27ae60; font-size: 1.4em; margin-top: 25px; }
                h4 { color: #8e44ad; font-size: 1.2em; margin-top: 20px; }
                .summary-box { background-color: #ecf0f1; padding: 20px; border-radius: 8px; margin: 20px 0; }
                .metric { display: inline-block; margin: 10px 20px 10px 0; }
                .metric-label { font-weight: bold; color: #2c3e50; }
                .metric-value { color: #e74c3c; font-size: 1.2em; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                th, td { border: 1px solid #bdc3c7; padding: 12px; text-align: left; }
                th { background-color: #3498db; color: white; font-weight: bold; }
                tr:nth-child(even) { background-color: #f8f9fa; }
                .plot-container { text-align: center; margin: 30px 0; }
                .plot-container img { max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 8px; }
                .insight { background-color: #e8f5e8; padding: 15px; border-left: 4px solid #27ae60; margin: 15px 0; }
                .warning { background-color: #fdf2e9; padding: 15px; border-left: 4px solid #e67e22; margin: 15px 0; }
                .error { background-color: #fadbd8; padding: 15px; border-left: 4px solid #e74c3c; margin: 15px 0; }
                .code { background-color: #2c3e50; color: #ecf0f1; padding: 15px; border-radius: 5px; font-family: 'Courier New', monospace; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Data Analysis Report</h1>
                <p>Generated on: {{ timestamp }}</p>
            </div>
            
            <div class="section">
                <h2>Executive Summary</h2>
                <div class="summary-box">
                    {{ executive_summary }}
                </div>
            </div>
            
            <div class="section">
                <h2>Dataset Overview</h2>
                <div class="subsection">
                    <h3>Basic Information</h3>
                    <table>
                        <tr><th>Metric</th><th>Value</th></tr>
                        <tr><td>Number of Rows</td><td>{{ overview.rows }}</td></tr>
                        <tr><td>Number of Columns</td><td>{{ overview.columns }}</td></tr>
                        <tr><td>Missing Values</td><td>{{ overview.missing_percentage }}%</td></tr>
                        <tr><td>Duplicate Rows</td><td>{{ overview.duplicate_percentage }}%</td></tr>
                        <tr><td>Memory Usage</td><td>{{ overview.memory_usage }} MB</td></tr>
                    </table>
                </div>
                
                <div class="subsection">
                    <h3>Column Types</h3>
                    <table>
                        <tr><th>Type</th><th>Count</th></tr>
                        {% for type, count in overview.column_types.items() %}
                        <tr><td>{{ type.title() }}</td><td>{{ count }}</td></tr>
                        {% endfor %}
                    </table>
                </div>
            </div>
            
            <div class="section">
                <h2>Data Quality Assessment</h2>
                <div class="subsection">
                    <h3>Quality Score: {{ quality_score }}/100</h3>
                    {% if quality_issues %}
                    <div class="warning">
                        <h4>Quality Issues Found:</h4>
                        <ul>
                            {% for issue in quality_issues %}
                            <li>{{ issue }}</li>
                            {% endfor %}
                        </ul>
                    </div>
                    {% else %}
                    <div class="insight">
                        <p>No significant data quality issues detected.</p>
                    </div>
                    {% endif %}
                </div>
            </div>
            
            <div class="section">
                <h2>Missing Values Analysis</h2>
                <div class="subsection">
                    <h3>Missing Values by Column</h3>
                    <table>
                        <tr><th>Column</th><th>Missing Count</th><th>Missing Percentage</th><th>Data Type</th></tr>
                        {% for col, info in missing_values.items() %}
                        <tr>
                            <td>{{ col }}</td>
                            <td>{{ info.count }}</td>
                            <td>{{ "%.2f"|format(info.percentage) }}%</td>
                            <td>{{ info.data_type }}</td>
                        </tr>
                        {% endfor %}
                    </table>
                </div>
            </div>
            
            <div class="section">
                <h2>Descriptive Statistics</h2>
                <div class="subsection">
                    <h3>Numeric Columns</h3>
                    {% if numeric_stats %}
                    <table>
                        <tr><th>Column</th><th>Mean</th><th>Std</th><th>Min</th><th>Max</th><th>Skewness</th></tr>
                        {% for col, stats in numeric_stats.items() %}
                        <tr>
                            <td>{{ col }}</td>
                            <td>{{ "%.2f"|format(stats['mean']) }}</td>
                            <td>{{ "%.2f"|format(stats['std']) }}</td>
                            <td>{{ "%.2f"|format(stats['min']) }}</td>
                            <td>{{ "%.2f"|format(stats['max']) }}</td>
                            <td>{{ "%.2f"|format(stats['skewness']) }}</td>
                        </tr>
                        {% endfor %}
                    </table>
                    {% else %}
                    <p>No numeric columns found.</p>
                    {% endif %}
                </div>
            </div>
            
            <div class="section">
                <h2>Preprocessing Summary</h2>
                <div class="subsection">
                    <h3>Applied Transformations</h3>
                    <ul>
                        {% for step in preprocessing_steps %}
                        <li>{{ step }}</li>
                        {% endfor %}
                    </ul>
                </div>
                
                <div class="subsection">
                    <h3>Shape Comparison</h3>
                    <table>
                        <tr><th>Dataset</th><th>Rows</th><th>Columns</th></tr>
                        <tr><td>Original</td><td>{{ original_shape.0 }}</td><td>{{ original_shape.1 }}</td></tr>
                        <tr><td>Processed</td><td>{{ processed_shape.0 }}</td><td>{{ processed_shape.1 }}</td></tr>
                    </table>
                </div>
            </div>
            
            <div class="section">
                <h2>Visualizations</h2>
                {% for plot_name, plot_img in plot_images.items() %}
                <div class="plot-container">
                    <h3>{{ plot_name.replace('_', ' ').title() }}</h3>
                    <img src="{{ plot_img }}" alt="{{ plot_name }}">
                </div>
                {% endfor %}
            </div>
            
            <div class="section">
                <h2>Key Insights</h2>
                <div class="subsection">
                    {% for insight in insights %}
                    <div class="insight">
                        <p>{{ insight }}</p>
                    </div>
                    {% endfor %}
                </div>
            </div>
            
            <div class="section">
                <h2>Recommendations</h2>
                <div class="subsection">
                    {% for recommendation in recommendations %}
                    <div class="insight">
                        <p>{{ recommendation }}</p>
                    </div>
                    {% endfor %}
                </div>
            </div>
        </body>
        </html>
        """
        
        # Prepare data for template
        numeric_stats = analysis_results['descriptive_statistics'].get('numeric', {})
        # Convert numeric stats to proper format for template
        if numeric_stats and 'mean' in numeric_stats:
            numeric_stats_formatted = {}
            for col in numeric_stats['mean'].keys():
                numeric_stats_formatted[col] = {
                    'mean': numeric_stats['mean'][col],
                    'std': numeric_stats['std'][col],
                    'min': numeric_stats['min'][col],
                    'max': numeric_stats['max'][col],
                    'skewness': numeric_stats['skewness'][col]
                }
            numeric_stats = numeric_stats_formatted
        
        template_data = {
            'timestamp': self.timestamp,
            'executive_summary': self._generate_executive_summary(analysis_results, preprocessing_summary),
            'overview': {
                'rows': f"{analysis_results['dataset_overview']['shape'][0]:,}",
                'columns': analysis_results['dataset_overview']['shape'][1],
                'missing_percentage': f"{analysis_results['dataset_overview']['missing_percentage']:.2f}",
                'duplicate_percentage': f"{analysis_results['dataset_overview']['duplicate_percentage']:.2f}",
                'memory_usage': f"{analysis_results['dataset_overview']['memory_usage'] / 1024**2:.2f}",
                'column_types': analysis_results['dataset_overview']['column_types']
            },
            'quality_score': analysis_results['data_quality']['quality_score'],
            'quality_issues': analysis_results['data_quality']['issues'],
            'missing_values': analysis_results['missing_values']['by_column'],
            'numeric_stats': numeric_stats,
            'preprocessing_steps': preprocessing_summary.get('steps', []),
            'original_shape': preprocessing_summary.get('original_shape', (0, 0)),
            'processed_shape': preprocessing_summary.get('processed_shape', (0, 0)),
            'plot_images': plot_images,
            'insights': self._generate_insights(analysis_results),
            'recommendations': self._generate_recommendations(analysis_results, preprocessing_summary)
        }
        
        # Render template
        template = Template(html_template)
        return template.render(**template_data)
    
    def _generate_executive_summary(self, analysis_results: Dict[str, Any], 
                                  preprocessing_summary: Dict[str, Any]) -> str:
        """Generate executive summary text."""
        overview = analysis_results['dataset_overview']
        quality = analysis_results['data_quality']
        
        summary = f"""
        This report presents a comprehensive analysis of a dataset containing {overview['shape'][0]:,} rows and {overview['shape'][1]} columns. 
        The dataset has a data quality score of {quality['quality_score']}/100 and contains {overview['missing_percentage']:.2f}% missing values.
        
        Key findings include the identification of {len(quality['issues'])} data quality issues and the application of {len(preprocessing_summary.get('steps', []))} preprocessing transformations.
        The analysis provides insights into data distributions, correlations, outliers, and missing value patterns to support informed decision-making.
        """
        
        return summary.strip()
    
    def _generate_insights(self, analysis_results: Dict[str, Any]) -> List[str]:
        """Generate key insights from the analysis."""
        insights = []
        
        # Dataset size insights
        shape = analysis_results['dataset_overview']['shape']
        insights.append(f"Dataset contains {shape[0]:,} observations across {shape[1]} features")
        
        # Missing data insights
        missing_pct = analysis_results['dataset_overview']['missing_percentage']
        if missing_pct > 0:
            insights.append(f"Missing data affects {missing_pct:.1f}% of all cells, requiring careful handling")
        else:
            insights.append("No missing values detected in the dataset")
        
        # Data quality insights
        quality_score = analysis_results['data_quality']['quality_score']
        if quality_score >= 80:
            insights.append("High data quality score indicates reliable dataset for analysis")
        elif quality_score >= 60:
            insights.append("Moderate data quality score suggests some data cleaning may be beneficial")
        else:
            insights.append("Low data quality score indicates significant data cleaning is required")
        
        # Outlier insights
        total_outliers = sum(
            col_outliers['iqr_outliers']['count'] 
            for col_outliers in analysis_results['outliers'].values()
        )
        if total_outliers > 0:
            insights.append(f"Detected {total_outliers} potential outliers that may need attention")
        
        # Correlation insights
        if 'high_correlations' in analysis_results['correlations']:
            high_corr = analysis_results['correlations']['high_correlations']
            if high_corr:
                insights.append(f"Found {len(high_corr)} pairs of highly correlated variables")
        
        return insights
    
    def _generate_recommendations(self, analysis_results: Dict[str, Any], 
                                preprocessing_summary: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on the analysis."""
        recommendations = []
        
        # Missing data recommendations
        missing_pct = analysis_results['dataset_overview']['missing_percentage']
        if missing_pct > 20:
            recommendations.append("Consider using advanced imputation techniques for high missing data percentage")
        elif missing_pct > 0:
            recommendations.append("Standard imputation methods should be sufficient for low missing data")
        
        # Data quality recommendations
        quality_issues = analysis_results['data_quality']['issues']
        if quality_issues:
            recommendations.append("Address identified data quality issues before proceeding with analysis")
        
        # Feature selection recommendations
        numeric_cols = analysis_results['dataset_overview']['column_types']['numeric']
        if numeric_cols > 10:
            recommendations.append("Consider feature selection techniques to reduce dimensionality")
        
        # Outlier recommendations
        total_outliers = sum(
            col_outliers['iqr_outliers']['count'] 
            for col_outliers in analysis_results['outliers'].values()
        )
        if total_outliers > analysis_results['dataset_overview']['shape'][0] * 0.05:
            recommendations.append("High number of outliers detected - consider outlier treatment strategies")
        
        # Preprocessing recommendations
        if preprocessing_summary.get('steps'):
            recommendations.append("Preprocessing pipeline successfully applied - data is ready for machine learning")
        
        return recommendations
    
    def _create_overview_table(self, overview: Dict[str, Any]) -> Table:
        """Create overview table for PDF."""
        data = [
            ['Metric', 'Value'],
            ['Number of Rows', f"{overview['shape'][0]:,}"],
            ['Number of Columns', str(overview['shape'][1])],
            ['Missing Values', f"{overview['missing_percentage']:.2f}%"],
            ['Duplicate Rows', f"{overview['duplicate_percentage']:.2f}%"],
            ['Memory Usage', f"{overview['memory_usage'] / 1024**2:.2f} MB"]
        ]
        
        table = Table(data)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        return table
    
    def _create_missing_values_table(self, missing_values: Dict[str, Any]) -> Table:
        """Create missing values table for PDF."""
        data = [['Column', 'Missing Count', 'Missing %', 'Data Type']]
        
        for col, info in missing_values['by_column'].items():
            if info['percentage'] > 0:
                data.append([
                    col,
                    str(info['count']),
                    f"{info['percentage']:.2f}%",
                    info['data_type']
                ])
        
        if len(data) == 1:
            data.append(['No missing values found', '', '', ''])
        
        table = Table(data)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        return table
    
    def _create_statistics_table(self, descriptive_stats: Dict[str, Any]) -> Table:
        """Create descriptive statistics table for PDF."""
        if 'numeric' not in descriptive_stats or not descriptive_stats['numeric']:
            return Paragraph("No numeric columns found for statistical analysis.", self.styles['Normal'])
        
        numeric_stats = descriptive_stats['numeric']
        data = [['Column', 'Mean', 'Std', 'Min', 'Max', 'Skewness']]
        
        for col in list(numeric_stats['mean'].keys())[:10]:  # Limit to first 10 columns
            data.append([
                col,
                f"{numeric_stats['mean'][col]:.2f}",
                f"{numeric_stats['std'][col]:.2f}",
                f"{numeric_stats['min'][col]:.2f}",
                f"{numeric_stats['max'][col]:.2f}",
                f"{numeric_stats['skewness'][col]:.2f}"
            ])
        
        table = Table(data)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        return table
    
    def _generate_quality_assessment(self, quality: Dict[str, Any]) -> str:
        """Generate quality assessment text."""
        score = quality['quality_score']
        issues = quality['issues']
        
        text = f"Data quality score: {score}/100\n\n"
        
        if issues:
            text += "Quality issues identified:\n"
            for issue in issues:
                text += f"• {issue}\n"
        else:
            text += "No significant quality issues detected."
        
        return text
    
    def _generate_preprocessing_summary(self, preprocessing_summary: Dict[str, Any]) -> str:
        """Generate preprocessing summary text."""
        steps = preprocessing_summary.get('steps', [])
        original_shape = preprocessing_summary.get('original_shape', (0, 0))
        processed_shape = preprocessing_summary.get('processed_shape', (0, 0))
        
        text = f"Applied {len(steps)} preprocessing transformations:\n\n"
        
        for i, step in enumerate(steps, 1):
            text += f"{i}. {step}\n"
        
        text += f"\nShape changed from {original_shape} to {processed_shape}"
        
        return text
