"""
Advanced EDA plots module for comprehensive data analysis visualizations.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Any, Optional
from scipy import stats
import warnings
warnings.filterwarnings('ignore')


class AdvancedEDAPlots:
    """Advanced EDA plots for comprehensive data analysis."""
    
    def __init__(self, figsize: tuple = (12, 8)):
        self.figsize = figsize
        self.colors = ['#00d4aa', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57', '#ff9ff3', '#54a0ff']
        
    def create_comprehensive_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create comprehensive EDA plots."""
        plots = {}
        
        # 1. Dataset overview plots
        plots.update(self._create_dataset_overview_plots(data, analysis_results))
        
        # 2. Univariate analysis plots
        plots.update(self._create_univariate_analysis_plots(data, analysis_results))
        
        # 3. Multivariate analysis plots
        plots.update(self._create_multivariate_analysis_plots(data, analysis_results))
        
        return plots
    
    def _create_dataset_overview_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create dataset overview plots."""
        plots = {}
        
        # Basic dataset overview
        fig, axes = plt.subplots(2, 2, figsize=self.figsize)
        fig.suptitle('Dataset Overview', fontsize=16, fontweight='bold')
        
        # Shape information
        shape = data.shape
        axes[0, 0].text(0.5, 0.5, f'Rows: {shape[0]:,}\nColumns: {shape[1]}', 
                        ha='center', va='center', fontsize=14, 
                        bbox=dict(boxstyle="round,pad=0.3", facecolor=self.colors[0], alpha=0.3))
        axes[0, 0].set_title('Dataset Shape')
        axes[0, 0].axis('off')
        
        # Data types
        dtype_counts = data.dtypes.value_counts()
        axes[0, 1].pie(dtype_counts.values, labels=dtype_counts.index, autopct='%1.1f%%', 
                      colors=self.colors[:len(dtype_counts)])
        axes[0, 1].set_title('Data Types Distribution')
        
        # Missing values
        missing_data = data.isnull().sum()
        missing_data = missing_data[missing_data > 0].sort_values(ascending=True)
        if not missing_data.empty:
            axes[1, 0].barh(missing_data.index, missing_data.values, color=self.colors[1])
            axes[1, 0].set_title('Missing Values by Column')
            axes[1, 0].set_xlabel('Missing Count')
        else:
            axes[1, 0].text(0.5, 0.5, 'No Missing Values', ha='center', va='center')
            axes[1, 0].set_title('Missing Values by Column')
        
        # Memory usage
        memory_usage = data.memory_usage(deep=True).sum() / 1024**2
        axes[1, 1].bar(['Memory Usage'], [memory_usage], color=self.colors[2])
        axes[1, 1].set_ylabel('Memory (MB)')
        axes[1, 1].set_title('Dataset Memory Usage')
        
        plt.tight_layout()
        plots['dataset_overview'] = fig
        
        return plots
    
    def _create_univariate_analysis_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create univariate analysis plots."""
        plots = {}
        
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        categorical_cols = data.select_dtypes(include=['object', 'category']).columns
        
        # Numeric univariate analysis
        if len(numeric_cols) > 0:
            plots['numeric_univariate'] = self._plot_numeric_univariate_analysis(data, numeric_cols)
            plots['numeric_distributions'] = self._plot_numeric_distributions(data, numeric_cols)
            plots['numeric_boxplots'] = self._plot_numeric_boxplots(data, numeric_cols)
        
        # Categorical univariate analysis
        if len(categorical_cols) > 0:
            plots['categorical_univariate'] = self._plot_categorical_univariate_analysis(data, categorical_cols)
            plots['categorical_distributions'] = self._plot_categorical_distributions(data, categorical_cols)
        
        return plots
    
    def _create_multivariate_analysis_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create multivariate analysis plots."""
        plots = {}
        
        numeric_data = data.select_dtypes(include=[np.number])
        
        if len(numeric_data.columns) > 1:
            # Correlation analysis
            plots['correlation_matrix'] = self._plot_correlation_matrix(numeric_data)
            plots['correlation_heatmap'] = self._plot_correlation_heatmap(numeric_data)
        
        return plots
    
    def _plot_numeric_univariate_analysis(self, data: pd.DataFrame, numeric_cols: List[str]) -> plt.Figure:
        """Plot numeric univariate analysis."""
        n_cols = min(4, len(numeric_cols))
        n_rows = (len(numeric_cols) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 4, n_rows * 3))
        if n_rows == 1:
            axes = [axes] if n_cols == 1 else axes
        else:
            axes = axes.flatten()
        
        for i, col in enumerate(numeric_cols):
            if i < len(axes):
                # Histogram
                data_col = data[col].dropna()
                axes[i].hist(data_col, bins=30, alpha=0.7, color=self.colors[i % len(self.colors)])
                axes[i].set_title(f'{col} Distribution')
                axes[i].set_xlabel(col)
                axes[i].set_ylabel('Frequency')
        
        # Hide empty subplots
        for i in range(len(numeric_cols), len(axes)):
            axes[i].set_visible(False)
        
        plt.suptitle('Numeric Univariate Analysis', fontsize=16, fontweight='bold')
        plt.tight_layout()
        return fig
    
    def _plot_numeric_distributions(self, data: pd.DataFrame, numeric_cols: List[str]) -> plt.Figure:
        """Plot numeric distributions."""
        n_cols = min(3, len(numeric_cols))
        n_rows = (len(numeric_cols) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 4, n_rows * 3))
        if n_rows == 1:
            axes = [axes] if n_cols == 1 else axes
        else:
            axes = axes.flatten()
        
        for i, col in enumerate(numeric_cols):
            if i < len(axes):
                # Histogram
                axes[i].hist(data[col].dropna(), bins=30, alpha=0.7, color=self.colors[i % len(self.colors)])
                axes[i].set_title(f'Distribution of {col}')
                axes[i].set_xlabel(col)
                axes[i].set_ylabel('Frequency')
        
        # Hide empty subplots
        for i in range(len(numeric_cols), len(axes)):
            axes[i].set_visible(False)
        
        plt.suptitle('Numeric Distributions', fontsize=16, fontweight='bold')
        plt.tight_layout()
        return fig
    
    def _plot_numeric_boxplots(self, data: pd.DataFrame, numeric_cols: List[str]) -> plt.Figure:
        """Plot numeric boxplots."""
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Prepare data for boxplot
        box_data = [data[col].dropna() for col in numeric_cols]
        
        # Create boxplot
        bp = ax.boxplot(box_data, labels=numeric_cols, patch_artist=True)
        
        # Color the boxes
        for patch, color in zip(bp['boxes'], self.colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        
        ax.set_title('Numeric Columns Boxplots')
        ax.set_ylabel('Value')
        ax.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        return fig
    
    def _plot_categorical_univariate_analysis(self, data: pd.DataFrame, categorical_cols: List[str]) -> plt.Figure:
        """Plot categorical univariate analysis."""
        n_cols = min(3, len(categorical_cols))
        n_rows = (len(categorical_cols) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 4, n_rows * 3))
        if n_rows == 1:
            axes = [axes] if n_cols == 1 else axes
        else:
            axes = axes.flatten()
        
        for i, col in enumerate(categorical_cols):
            if i < len(axes):
                # Value counts
                value_counts = data[col].value_counts().head(10)
                
                # Create bar plot
                bars = axes[i].bar(range(len(value_counts)), value_counts.values, 
                                 color=self.colors[:len(value_counts)])
                axes[i].set_xticks(range(len(value_counts)))
                axes[i].set_xticklabels(value_counts.index, rotation=45, ha='right')
                axes[i].set_title(f'Top Values in {col}')
                axes[i].set_ylabel('Count')
        
        # Hide empty  
        for i in range(len(categorical_cols), len(axes)):
            axes[i].set_visible(False)
        
        plt.suptitle('Categorical Univariate Analysis', fontsize=16, fontweight='bold')
        plt.tight_layout()
        return fig
    
    def _plot_categorical_distributions(self, data: pd.DataFrame, categorical_cols: List[str]) -> plt.Figure:
        """Plot categorical distributions."""
        n_cols = min(3, len(categorical_cols))
        n_rows = (len(categorical_cols) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 4, n_rows * 3))
        if n_rows == 1:
            axes = [axes] if n_cols == 1 else axes
        else:
            axes = axes.flatten()
        
        for i, col in enumerate(categorical_cols):
            if i < len(axes):
                # Get value counts
                value_counts = data[col].value_counts().head(10)
                
                # Create bar plot
                bars = axes[i].bar(range(len(value_counts)), value_counts.values, 
                                 color=self.colors[:len(value_counts)])
                axes[i].set_xticks(range(len(value_counts)))
                axes[i].set_xticklabels(value_counts.index, rotation=45, ha='right')
                axes[i].set_title(f'Distribution of {col}')
                axes[i].set_ylabel('Count')
        
        # Hide empty subplots
        for i in range(len(categorical_cols), len(axes)):
            axes[i].set_visible(False)
        
        plt.suptitle('Categorical Distributions', fontsize=16, fontweight='bold')
        plt.tight_layout()
        return fig
    
    def _plot_correlation_matrix(self, numeric_data: pd.DataFrame) -> plt.Figure:
        """Plot correlation matrix."""
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Calculate correlation matrix
        corr_matrix = numeric_data.corr()
        
        # Create heatmap
        mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
        sns.heatmap(corr_matrix, mask=mask, annot=True, cmap='coolwarm', center=0,
                   square=True, linewidths=0.5, cbar_kws={"shrink": 0.8}, ax=ax)
        
        ax.set_title('Correlation Matrix')
        
        plt.tight_layout()
        return fig
    
    def _plot_correlation_heatmap(self, numeric_data: pd.DataFrame) -> plt.Figure:
        """Plot correlation heatmap."""
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Calculate correlation matrix
        corr_matrix = numeric_data.corr()
        
        # Create heatmap
        mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
        sns.heatmap(corr_matrix, mask=mask, annot=True, cmap='RdYlBu_r', center=0,
                   square=True, linewidths=0.5, cbar_kws={"shrink": 0.8}, ax=ax)
        
        ax.set_title('Correlation Heatmap')
        
        plt.tight_layout()
        return fig