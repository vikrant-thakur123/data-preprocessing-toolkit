"""
Comprehensive test script for the data analysis system.
"""

import pandas as pd
import numpy as np
import os
import tempfile
import sys
from pathlib import Path

# Import custom modules
from data_loader import DataLoader
from data_analyzer import DataAnalyzer
from preprocessing import DataPreprocessor
from visualizations import DataVisualizer
from report_generator import ReportGenerator
from sample_data_generator import generate_sample_dataset


def test_data_loader():
    """Test the DataLoader module."""
    print("🧪 Testing DataLoader...")
    
    # Generate sample data
    data = generate_sample_dataset(n_samples=100, missing_percentage=0.1)
    
    # Save to temporary CSV file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        data.to_csv(f.name, index=False)
        temp_file = f.name
    
    try:
        # Test loading
        loader = DataLoader()
        loaded_data = loader.load_data(temp_file)
        
        # Test basic functionality
        assert loaded_data.shape == data.shape, "Shape mismatch"
        assert list(loaded_data.columns) == list(data.columns), "Column mismatch"
        
        # Test data info
        info = loader.get_data_info()
        assert info['shape'] == data.shape, "Info shape mismatch"
        
        # Test validation
        validation = loader.validate_data()
        assert 'has_duplicates' in validation, "Validation missing key"
        
        # Test column types
        column_types = loader.get_column_types()
        assert 'numeric' in column_types, "Missing numeric columns"
        assert 'categorical' in column_types, "Missing categorical columns"
        
        print("✅ DataLoader tests passed")
        return True
        
    except Exception as e:
        print(f"❌ DataLoader test failed: {e}")
        return False
    finally:
        # Clean up
        os.unlink(temp_file)


def test_data_analyzer():
    """Test the DataAnalyzer module."""
    print("🧪 Testing DataAnalyzer...")
    
    try:
        # Generate sample data
        data = generate_sample_dataset(n_samples=200, missing_percentage=0.15)
        
        # Test analysis
        analyzer = DataAnalyzer()
        results = analyzer.analyze(data)
        
        # Test required keys
        required_keys = [
            'dataset_overview', 'descriptive_statistics', 'correlations',
            'distributions', 'missing_values', 'outliers', 'data_quality',
            'column_analysis'
        ]
        
        for key in required_keys:
            assert key in results, f"Missing key: {key}"
        
        # Test dataset overview
        overview = results['dataset_overview']
        assert 'shape' in overview, "Missing shape in overview"
        assert overview['shape'] == data.shape, "Shape mismatch in overview"
        
        # Test descriptive statistics
        desc_stats = results['descriptive_statistics']
        assert 'numeric' in desc_stats or 'categorical' in desc_stats, "No statistics found"
        
        # Test missing values analysis
        missing = results['missing_values']
        assert 'overall' in missing, "Missing overall missing analysis"
        assert 'by_column' in missing, "Missing by_column analysis"
        
        # Test insights generation
        insights = analyzer.get_summary_insights()
        assert isinstance(insights, list), "Insights should be a list"
        assert len(insights) > 0, "No insights generated"
        
        print("✅ DataAnalyzer tests passed")
        return True
        
    except Exception as e:
        print(f"❌ DataAnalyzer test failed: {e}")
        return False


def test_preprocessing():
    """Test the DataPreprocessor module."""
    print("🧪 Testing DataPreprocessor...")
    
    try:
        # Generate sample data
        data = generate_sample_dataset(n_samples=200, missing_percentage=0.2)
        
        # Test different preprocessing strategies
        strategies = [
            ('auto', 'auto', 'standard'),
            ('fill_mean', 'one_hot', 'minmax'),
            ('knn', 'label', 'robust')
        ]
        
        for missing_strategy, encoding_strategy, scaling_strategy in strategies:
            preprocessor = DataPreprocessor()
            processed_data = preprocessor.preprocess(
                data,
                missing_value_strategy=missing_strategy,
                encoding_strategy=encoding_strategy,
                scaling_strategy=scaling_strategy,
                feature_selection=True,
                dimensionality_reduction=False
            )
            
            # Test that preprocessing was applied
            assert processed_data is not None, "Processed data is None"
            assert not processed_data.isnull().any().any(), "Missing values not handled"
            
            # Test summary
            summary = preprocessor.get_preprocessing_summary()
            assert 'steps' in summary, "Missing steps in summary"
            assert len(summary['steps']) > 0, "No preprocessing steps applied"
        
        print("✅ DataPreprocessor tests passed")
        return True
        
    except Exception as e:
        print(f"❌ DataPreprocessor test failed: {e}")
        return False


def test_visualizations():
    """Test the DataVisualizer module."""
    print("🧪 Testing DataVisualizer...")
    
    try:
        # Generate sample data
        data = generate_sample_dataset(n_samples=200, missing_percentage=0.1)
        
        # Generate analysis results
        analyzer = DataAnalyzer()
        analysis_results = analyzer.analyze(data)
        
        # Test visualizer
        visualizer = DataVisualizer()
        
        # Test different plot types
        overview_plots = visualizer.create_overview_plots(data, analysis_results)
        assert isinstance(overview_plots, dict), "Overview plots should be a dict"
        
        dist_plots = visualizer.create_distribution_plots(data, analysis_results)
        assert isinstance(dist_plots, dict), "Distribution plots should be a dict"
        
        corr_plots = visualizer.create_correlation_plots(data, analysis_results)
        assert isinstance(corr_plots, dict), "Correlation plots should be a dict"
        
        outlier_plots = visualizer.create_outlier_plots(data, analysis_results)
        assert isinstance(outlier_plots, dict), "Outlier plots should be a dict"
        
        # Test plot saving
        with tempfile.TemporaryDirectory() as temp_dir:
            all_plots = {**overview_plots, **dist_plots, **corr_plots, **outlier_plots}
            visualizer.save_plots(all_plots, temp_dir)
            
            # Check if plots were saved
            plot_files = list(Path(temp_dir).glob("*.png"))
            assert len(plot_files) > 0, "No plots were saved"
        
        print("✅ DataVisualizer tests passed")
        return True
        
    except Exception as e:
        print(f"❌ DataVisualizer test failed: {e}")
        return False


def test_report_generator():
    """Test the ReportGenerator module."""
    print("🧪 Testing ReportGenerator...")
    
    try:
        # Generate sample data
        data = generate_sample_dataset(n_samples=200, missing_percentage=0.1)
        
        # Generate analysis results
        analyzer = DataAnalyzer()
        analysis_results = analyzer.analyze(data)
        
        # Generate preprocessing results
        preprocessor = DataPreprocessor()
        processed_data = preprocessor.preprocess(data)
        preprocessing_summary = preprocessor.get_preprocessing_summary()
        
        # Generate plots
        visualizer = DataVisualizer()
        plots = visualizer.create_overview_plots(data, analysis_results)
        
        # Test report generator
        report_generator = ReportGenerator()
        
        # Test HTML report generation
        with tempfile.NamedTemporaryFile(suffix='.html', delete=False) as f:
            html_path = f.name
        
        report_generator.generate_html_report(
            data, analysis_results, preprocessing_summary, plots, html_path
        )
        
        # Check if HTML file was created
        assert os.path.exists(html_path), "HTML report not created"
        assert os.path.getsize(html_path) > 0, "HTML report is empty"
        
        # Test PDF report generation
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
            pdf_path = f.name
        
        report_generator.generate_pdf_report(
            data, analysis_results, preprocessing_summary, plots, pdf_path
        )
        
        # Check if PDF file was created
        assert os.path.exists(pdf_path), "PDF report not created"
        assert os.path.getsize(pdf_path) > 0, "PDF report is empty"
        
        # Clean up
        os.unlink(html_path)
        os.unlink(pdf_path)
        
        print("✅ ReportGenerator tests passed")
        return True
        
    except Exception as e:
        print(f"❌ ReportGenerator test failed: {e}")
        return False


def test_end_to_end():
    """Test the complete end-to-end workflow."""
    print("🧪 Testing End-to-End Workflow...")
    
    try:
        # Generate sample data
        data = generate_sample_dataset(n_samples=500, missing_percentage=0.2)
        
        # Step 1: Load data
        loader = DataLoader()
        # Simulate loading by using the data directly
        loader.data = data
        
        # Step 2: Analyze data
        analyzer = DataAnalyzer()
        analysis_results = analyzer.analyze(data)
        
        # Step 3: Preprocess data
        preprocessor = DataPreprocessor()
        processed_data = preprocessor.preprocess(
            data,
            missing_value_strategy='auto',
            encoding_strategy='auto',
            scaling_strategy='standard',
            feature_selection=True,
            dimensionality_reduction=False
        )
        
        # Step 4: Generate visualizations
        visualizer = DataVisualizer()
        plots = visualizer.create_overview_plots(data, analysis_results)
        plots.update(visualizer.create_distribution_plots(data, analysis_results))
        plots.update(visualizer.create_correlation_plots(data, analysis_results))
        plots.update(visualizer.create_outlier_plots(data, analysis_results))
        plots.update(visualizer.create_preprocessing_plots(data, processed_data))
        
        # Step 5: Generate reports
        report_generator = ReportGenerator()
        preprocessing_summary = preprocessor.get_preprocessing_summary()
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Generate HTML report
            html_path = os.path.join(temp_dir, 'test_report.html')
            report_generator.generate_html_report(
                data, analysis_results, preprocessing_summary, plots, html_path
            )
            
            # Generate PDF report
            pdf_path = os.path.join(temp_dir, 'test_report.pdf')
            report_generator.generate_pdf_report(
                data, analysis_results, preprocessing_summary, plots, pdf_path
            )
            
            # Save processed data
            processed_path = os.path.join(temp_dir, 'processed_data.csv')
            processed_data.to_csv(processed_path, index=False)
            
            # Verify all outputs were created
            assert os.path.exists(html_path), "HTML report not created"
            assert os.path.exists(pdf_path), "PDF report not created"
            assert os.path.exists(processed_path), "Processed data not saved"
            
            # Verify file sizes
            assert os.path.getsize(html_path) > 0, "HTML report is empty"
            assert os.path.getsize(pdf_path) > 0, "PDF report is empty"
            assert os.path.getsize(processed_path) > 0, "Processed data is empty"
        
        print("✅ End-to-End workflow tests passed")
        return True
        
    except Exception as e:
        print(f"❌ End-to-End test failed: {e}")
        return False


def run_all_tests():
    """Run all tests and report results."""
    print("🚀 Starting Comprehensive Test Suite")
    print("=" * 50)
    
    tests = [
        ("DataLoader", test_data_loader),
        ("DataAnalyzer", test_data_analyzer),
        ("DataPreprocessor", test_preprocessing),
        ("DataVisualizer", test_visualizations),
        ("ReportGenerator", test_report_generator),
        ("End-to-End Workflow", test_end_to_end)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        print(f"\n🔍 Running {test_name} tests...")
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"❌ {test_name} test crashed: {e}")
            failed += 1
    
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All tests passed! The system is working correctly.")
        return True
    else:
        print("⚠️  Some tests failed. Please check the errors above.")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)

