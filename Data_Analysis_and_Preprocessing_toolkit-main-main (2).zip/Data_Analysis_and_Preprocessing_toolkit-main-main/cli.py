"""
Command-line interface for the data analysis system.
"""

import argparse
import pandas as pd
import sys
import os
from pathlib import Path

# Import custom modules
from data_loader import DataLoader
from data_analyzer import DataAnalyzer
from preprocessing import DataPreprocessor
from visualizations import DataVisualizer
from report_generator import ReportGenerator


def main():
    """Main CLI function."""
    parser = argparse.ArgumentParser(
        description="Automated Data Analysis and Preprocessing System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cli.py data.csv --analyze --preprocess --report
  python cli.py data.xlsx --missing-strategy knn --encoding one_hot --output processed_data.csv
  python cli.py data.csv --analyze --visualize --output-dir results/
        """
    )
    
    # Required arguments
    parser.add_argument('input_file', help='Input CSV or Excel file')
    
    # Analysis options
    parser.add_argument('--analyze', action='store_true', help='Run data analysis')
    parser.add_argument('--preprocess', action='store_true', help='Run preprocessing')
    parser.add_argument('--visualize', action='store_true', help='Generate visualizations')
    parser.add_argument('--report', action='store_true', help='Generate reports')
    
    # Preprocessing options
    parser.add_argument('--missing-strategy', 
                       choices=['auto', 'drop', 'fill_mean', 'fill_median', 'interpolate', 'knn'],
                       default='auto', help='Missing value handling strategy')
    parser.add_argument('--encoding', 
                       choices=['auto', 'one_hot', 'label', 'ordinal'],
                       default='auto', help='Categorical encoding strategy')
    parser.add_argument('--scaling', 
                       choices=['standard', 'minmax', 'robust', 'none'],
                       default='standard', help='Scaling strategy')
    parser.add_argument('--feature-selection', action='store_true', 
                       help='Enable feature selection')
    parser.add_argument('--dimensionality-reduction', action='store_true',
                       help='Enable dimensionality reduction')
    parser.add_argument('--target-column', help='Target column for supervised methods')
    
    # Output options
    parser.add_argument('--output', '-o', help='Output file for processed data')
    parser.add_argument('--output-dir', default='output', help='Output directory for reports and plots')
    parser.add_argument('--format', choices=['csv', 'excel'], default='csv',
                       help='Output format for processed data')
    
    # Visualization options
    parser.add_argument('--plot-format', choices=['png', 'pdf', 'svg'], default='png',
                       help='Plot output format')
    parser.add_argument('--plot-dpi', type=int, default=300, help='Plot DPI')
    
    # Report options
    parser.add_argument('--report-format', choices=['html', 'pdf', 'both'], default='both',
                       help='Report output format')
    
    args = parser.parse_args()
    
    # Validate input file
    if not os.path.exists(args.input_file):
        print(f"Error: Input file '{args.input_file}' not found.")
        sys.exit(1)
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    try:
        # Load data
        print("Loading data...")
        loader = DataLoader()
        data = loader.load_data(args.input_file)
        print(f"✅ Loaded {data.shape[0]:,} rows and {data.shape[1]} columns")
        
        analysis_results = None
        processed_data = None
        plots = {}
        
        # Run analysis
        if args.analyze:
            print("Running data analysis...")
            analyzer = DataAnalyzer()
            analysis_results = analyzer.analyze(data)
            print("✅ Analysis completed")
            
            # Print key insights
            insights = analyzer.get_summary_insights()
            print("\n📊 Key Insights:")
            for insight in insights:
                print(f"  • {insight}")
        
        # Run preprocessing
        if args.preprocess:
            print("Running preprocessing...")
            preprocessor = DataPreprocessor()
            processed_data = preprocessor.preprocess(
                data,
                missing_value_strategy=args.missing_strategy,
                encoding_strategy=args.encoding,
                scaling_strategy=args.scaling,
                feature_selection=args.feature_selection,
                dimensionality_reduction=args.dimensionality_reduction,
                target_column=args.target_column
            )
            print("✅ Preprocessing completed")
            
            # Save processed data
            if args.output:
                if args.format == 'csv':
                    processed_data.to_csv(args.output, index=False)
                else:
                    processed_data.to_excel(args.output, index=False)
                print(f"✅ Processed data saved to {args.output}")
        
        # Generate visualizations
        if args.visualize:
            print("Generating visualizations...")
            visualizer = DataVisualizer()
            
            if analysis_results:
                # Overview plots
                overview_plots = visualizer.create_overview_plots(data, analysis_results)
                plots.update(overview_plots)
                
                # Distribution plots
                dist_plots = visualizer.create_distribution_plots(data, analysis_results)
                plots.update(dist_plots)
                
                # Correlation plots
                corr_plots = visualizer.create_correlation_plots(data, analysis_results)
                plots.update(corr_plots)
                
                # Outlier plots
                outlier_plots = visualizer.create_outlier_plots(data, analysis_results)
                plots.update(outlier_plots)
            
            if processed_data is not None:
                # Preprocessing plots
                prep_plots = visualizer.create_preprocessing_plots(data, processed_data)
                plots.update(prep_plots)
            
            # Save plots
            plot_dir = os.path.join(args.output_dir, 'plots')
            os.makedirs(plot_dir, exist_ok=True)
            visualizer.save_plots(plots, plot_dir)
            print(f"✅ Visualizations saved to {plot_dir}/")
        
        # Generate reports
        if args.report:
            print("Generating reports...")
            report_generator = ReportGenerator()
            
            if analysis_results:
                preprocessing_summary = preprocessor.get_preprocessing_summary() if processed_data is not None else {}
                
                if args.report_format in ['html', 'both']:
                    html_path = os.path.join(args.output_dir, 'analysis_report.html')
                    report_generator.generate_html_report(
                        data, analysis_results, preprocessing_summary, plots, html_path
                    )
                    print(f"✅ HTML report saved to {html_path}")
                
                if args.report_format in ['pdf', 'both']:
                    pdf_path = os.path.join(args.output_dir, 'analysis_report.pdf')
                    report_generator.generate_pdf_report(
                        data, analysis_results, preprocessing_summary, plots, pdf_path
                    )
                    print(f"✅ PDF report saved to {pdf_path}")
            else:
                print("⚠️  No analysis results available for report generation")
        
        print("\n🎉 All tasks completed successfully!")
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()

