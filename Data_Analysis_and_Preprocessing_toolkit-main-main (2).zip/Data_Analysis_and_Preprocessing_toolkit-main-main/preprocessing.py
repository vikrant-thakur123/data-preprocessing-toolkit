"""
Comprehensive data preprocessing pipeline.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional, Any, Union
from sklearn.preprocessing import (
    StandardScaler, MinMaxScaler, RobustScaler, 
    LabelEncoder, OneHotEncoder, OrdinalEncoder
)
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.feature_selection import (
    SelectKBest, SelectPercentile, RFE, 
    f_regression, f_classif, mutual_info_regression, mutual_info_classif
)
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.manifold import TSNE
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
import warnings
warnings.filterwarnings('ignore')


class DataPreprocessor:
    """Comprehensive data preprocessing pipeline."""
    
    def __init__(self):
        self.data = None
        self.processed_data = None
        self.preprocessing_steps = []
        self.encoders = {}
        self.scalers = {}
        self.feature_selectors = {}
        self.dimensionality_reducers = {}
        self.column_types = {}
        
    def preprocess(self, data: pd.DataFrame, 
                   missing_value_strategy: str = 'auto',
                   encoding_strategy: str = 'auto',
                   scaling_strategy: str = 'standard',
                   feature_selection: bool = True,
                   dimensionality_reduction: bool = False,
                   target_column: Optional[str] = None,
                   manual_imputation_settings: Optional[Dict[str, Dict[str, Any]]] = None) -> pd.DataFrame:
        """
        Apply comprehensive preprocessing pipeline.
        
        Args:
            data (pd.DataFrame): Input dataset
            missing_value_strategy (str): Strategy for handling missing values
            encoding_strategy (str): Strategy for encoding categorical variables
            scaling_strategy (str): Strategy for scaling numerical variables
            feature_selection (bool): Whether to perform feature selection
            dimensionality_reduction (bool): Whether to perform dimensionality reduction
            target_column (str): Target column for supervised feature selection
            
        Returns:
            pd.DataFrame: Preprocessed dataset
        """
        self.data = data.copy()
        self.column_types = self._categorize_columns()
        
        # Step 1: Handle missing values
        self.processed_data = self._handle_missing_values(
            self.data, strategy=missing_value_strategy, manual_settings=manual_imputation_settings
        )
        
        # Step 2: Encode categorical variables
        self.processed_data = self._encode_categorical_variables(
            self.processed_data, strategy=encoding_strategy
        )
        
        # Step 3: Scale numerical variables
        self.processed_data = self._scale_numerical_variables(
            self.processed_data, strategy=scaling_strategy
        )
        
        # Step 4: Feature selection
        if feature_selection:
            self.processed_data = self._select_features(
                self.processed_data, target_column=target_column
            )
        
        # Step 5: Dimensionality reduction
        if dimensionality_reduction:
            self.processed_data = self._reduce_dimensionality(
                self.processed_data, target_column=target_column
            )
        
        return self.processed_data
    
    def _categorize_columns(self) -> Dict[str, List[str]]:
        """Categorize columns by data type."""
        numeric_columns = self.data.select_dtypes(include=[np.number]).columns.tolist()
        categorical_columns = self.data.select_dtypes(include=['object', 'category']).columns.tolist()
        datetime_columns = self.data.select_dtypes(include=['datetime64']).columns.tolist()
        boolean_columns = self.data.select_dtypes(include=['bool']).columns.tolist()
        
        return {
            'numeric': numeric_columns,
            'categorical': categorical_columns,
            'datetime': datetime_columns,
            'boolean': boolean_columns
        }
    
    def _handle_missing_values(self, data: pd.DataFrame, strategy: str = 'auto', 
                              manual_settings: Optional[Dict[str, Dict[str, Any]]] = None) -> pd.DataFrame:
        """Handle missing values based on strategy."""
        processed_data = data.copy()
        
        if strategy == 'manual' and manual_settings:
            # Manual strategy: use user-specified settings for each column
            for col, settings in manual_settings.items():
                if col in processed_data.columns:
                    method = settings['method']
                    
                    if method == 'drop_column':
                        processed_data = processed_data.drop(columns=[col])
                        self.preprocessing_steps.append(f"Dropped column '{col}' (manual setting)")
                    elif method == 'custom':
                        custom_value = settings['value']
                        processed_data[col] = processed_data[col].fillna(custom_value)
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with custom value: {custom_value}")
                    elif method == 'mean':
                        processed_data[col] = processed_data[col].fillna(processed_data[col].mean())
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with mean")
                    elif method == 'median':
                        processed_data[col] = processed_data[col].fillna(processed_data[col].median())
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with median")
                    elif method == 'mode':
                        mode_value = processed_data[col].mode()[0] if not processed_data[col].mode().empty else 'Unknown'
                        processed_data[col] = processed_data[col].fillna(mode_value)
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with mode")
                    elif method == 'interpolate':
                        processed_data[col] = processed_data[col].interpolate(method='linear')
                        self.preprocessing_steps.append(f"Interpolated missing values in '{col}'")
                    elif method == 'knn':
                        # Use KNN imputation for this specific column
                        from sklearn.impute import KNNImputer
                        knn_imputer = KNNImputer(n_neighbors=5)
                        processed_data[col] = knn_imputer.fit_transform(processed_data[[col]]).flatten()
                        self.preprocessing_steps.append(f"Used KNN imputation for '{col}'")
        
        elif strategy == 'auto':
            # Auto strategy: use different methods based on data type and missing percentage
            for col in data.columns:
                missing_pct = (data[col].isnull().sum() / len(data)) * 100
                
                if missing_pct > 50:
                    # Drop columns with >50% missing values
                    processed_data = processed_data.drop(columns=[col])
                    self.preprocessing_steps.append(f"Dropped column '{col}' (missing: {missing_pct:.1f}%)")
                elif missing_pct > 0:
                    if col in self.column_types['numeric']:
                        # Use median for numeric columns
                        processed_data[col] = processed_data[col].fillna(processed_data[col].median())
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with median")
                    else:
                        # Use mode for categorical columns
                        mode_value = processed_data[col].mode()[0] if not processed_data[col].mode().empty else 'Unknown'
                        processed_data[col] = processed_data[col].fillna(mode_value)
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with mode")
        
        elif strategy == 'drop':
            # Drop rows with any missing values
            original_len = len(processed_data)
            processed_data = processed_data.dropna()
            dropped_rows = original_len - len(processed_data)
            self.preprocessing_steps.append(f"Dropped {dropped_rows} rows with missing values")
        
        elif strategy == 'fill_mean':
            # Fill numeric columns with mean, categorical with mode
            for col in processed_data.columns:
                if processed_data[col].isnull().any():
                    if col in self.column_types['numeric']:
                        processed_data[col] = processed_data[col].fillna(processed_data[col].mean())
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with mean")
                    else:
                        mode_value = processed_data[col].mode()[0] if not processed_data[col].mode().empty else 'Unknown'
                        processed_data[col] = processed_data[col].fillna(mode_value)
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with mode")
        
        elif strategy == 'fill_median':
            # Fill numeric columns with median, categorical with mode
            for col in processed_data.columns:
                if processed_data[col].isnull().any():
                    if col in self.column_types['numeric']:
                        processed_data[col] = processed_data[col].fillna(processed_data[col].median())
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with median")
                    else:
                        mode_value = processed_data[col].mode()[0] if not processed_data[col].mode().empty else 'Unknown'
                        processed_data[col] = processed_data[col].fillna(mode_value)
                        self.preprocessing_steps.append(f"Filled missing values in '{col}' with mode")
        
        elif strategy == 'interpolate':
            # Use interpolation for numeric columns
            for col in self.column_types['numeric']:
                if processed_data[col].isnull().any():
                    processed_data[col] = processed_data[col].interpolate(method='linear')
                    self.preprocessing_steps.append(f"Interpolated missing values in '{col}'")
            
            # Fill remaining categorical missing values with mode
            for col in self.column_types['categorical']:
                if processed_data[col].isnull().any():
                    mode_value = processed_data[col].mode()[0] if not processed_data[col].mode().empty else 'Unknown'
                    processed_data[col] = processed_data[col].fillna(mode_value)
                    self.preprocessing_steps.append(f"Filled missing values in '{col}' with mode")
        
        elif strategy == 'knn':
            # Use KNN imputation for numeric columns
            numeric_cols = [col for col in self.column_types['numeric'] if processed_data[col].isnull().any()]
            if numeric_cols:
                knn_imputer = KNNImputer(n_neighbors=5)
                processed_data[numeric_cols] = knn_imputer.fit_transform(processed_data[numeric_cols])
                self.preprocessing_steps.append(f"Used KNN imputation for numeric columns: {numeric_cols}")
            
            # Fill categorical missing values with mode
            for col in self.column_types['categorical']:
                if processed_data[col].isnull().any():
                    mode_value = processed_data[col].mode()[0] if not processed_data[col].mode().empty else 'Unknown'
                    processed_data[col] = processed_data[col].fillna(mode_value)
                    self.preprocessing_steps.append(f"Filled missing values in '{col}' with mode")
        
        return processed_data
    
    def _encode_categorical_variables(self, data: pd.DataFrame, strategy: str = 'auto') -> pd.DataFrame:
        """Encode categorical variables based on strategy."""
        processed_data = data.copy()
        
        if strategy == 'auto':
            # Auto strategy: use different encoding based on cardinality
            for col in self.column_types['categorical']:
                if col in processed_data.columns:
                    unique_count = processed_data[col].nunique()
                    
                    if unique_count <= 10:
                        # Low cardinality: use one-hot encoding
                        processed_data = self._one_hot_encode(processed_data, col)
                    else:
                        # High cardinality: use label encoding
                        processed_data = self._label_encode(processed_data, col)
        
        elif strategy == 'one_hot':
            # One-hot encode all categorical variables
            for col in self.column_types['categorical']:
                if col in processed_data.columns:
                    processed_data = self._one_hot_encode(processed_data, col)
        
        elif strategy == 'label':
            # Label encode all categorical variables
            for col in self.column_types['categorical']:
                if col in processed_data.columns:
                    processed_data = self._label_encode(processed_data, col)
        
        elif strategy == 'ordinal':
            # Ordinal encode all categorical variables
            for col in self.column_types['categorical']:
                if col in processed_data.columns:
                    processed_data = self._ordinal_encode(processed_data, col)
        
        return processed_data
    
    def _one_hot_encode(self, data: pd.DataFrame, column: str) -> pd.DataFrame:
        """Apply one-hot encoding to a column."""
        encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
        encoded_data = encoder.fit_transform(data[[column]])
        
        # Create column names
        feature_names = [f"{column}_{cat}" for cat in encoder.categories_[0]]
        
        # Create DataFrame with encoded data
        encoded_df = pd.DataFrame(encoded_data, columns=feature_names, index=data.index)
        
        # Drop original column and add encoded columns
        data_encoded = data.drop(columns=[column])
        data_encoded = pd.concat([data_encoded, encoded_df], axis=1)
        
        # Store encoder for potential inverse transformation
        self.encoders[f"{column}_onehot"] = encoder
        
        self.preprocessing_steps.append(f"One-hot encoded '{column}' into {len(feature_names)} features")
        return data_encoded
    
    def _label_encode(self, data: pd.DataFrame, column: str) -> pd.DataFrame:
        """Apply label encoding to a column."""
        encoder = LabelEncoder()
        data_encoded = data.copy()
        data_encoded[column] = encoder.fit_transform(data[column].astype(str))
        
        # Store encoder for potential inverse transformation
        self.encoders[f"{column}_label"] = encoder
        
        self.preprocessing_steps.append(f"Label encoded '{column}'")
        return data_encoded
    
    def _ordinal_encode(self, data: pd.DataFrame, column: str) -> pd.DataFrame:
        """Apply ordinal encoding to a column."""
        encoder = OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)
        data_encoded = data.copy()
        data_encoded[column] = encoder.fit_transform(data[[column]]).flatten()
        
        # Store encoder for potential inverse transformation
        self.encoders[f"{column}_ordinal"] = encoder
        
        self.preprocessing_steps.append(f"Ordinal encoded '{column}'")
        return data_encoded
    
    def _scale_numerical_variables(self, data: pd.DataFrame, strategy: str = 'standard') -> pd.DataFrame:
        """Scale numerical variables based on strategy."""
        processed_data = data.copy()
        numeric_columns = [col for col in self.column_types['numeric'] if col in processed_data.columns]
        
        if not numeric_columns:
            return processed_data
        
        if strategy == 'standard':
            scaler = StandardScaler()
            processed_data[numeric_columns] = scaler.fit_transform(processed_data[numeric_columns])
            self.scalers['standard'] = scaler
            self.preprocessing_steps.append(f"Standard scaled {len(numeric_columns)} numeric columns")
        
        elif strategy == 'minmax':
            scaler = MinMaxScaler()
            processed_data[numeric_columns] = scaler.fit_transform(processed_data[numeric_columns])
            self.scalers['minmax'] = scaler
            self.preprocessing_steps.append(f"MinMax scaled {len(numeric_columns)} numeric columns")
        
        elif strategy == 'robust':
            scaler = RobustScaler()
            processed_data[numeric_columns] = scaler.fit_transform(processed_data[numeric_columns])
            self.scalers['robust'] = scaler
            self.preprocessing_steps.append(f"Robust scaled {len(numeric_columns)} numeric columns")
        
        elif strategy == 'none':
            self.preprocessing_steps.append("No scaling applied to numeric columns")
        
        return processed_data
    
    def _select_features(self, data: pd.DataFrame, target_column: Optional[str] = None) -> pd.DataFrame:
        """Perform feature selection."""
        processed_data = data.copy()
        
        # Get numeric columns for feature selection
        numeric_columns = [col for col in self.column_types['numeric'] if col in processed_data.columns]
        
        if len(numeric_columns) < 2:
            return processed_data
        
        # Determine number of features to select
        n_features = min(20, len(numeric_columns), len(processed_data) // 10)
        
        if target_column and target_column in processed_data.columns:
            # Supervised feature selection
            X = processed_data[numeric_columns]
            y = processed_data[target_column]
            
            # Check if target is numeric or categorical
            if y.dtype in ['object', 'category']:
                # Classification
                selector = SelectKBest(score_func=f_classif, k=n_features)
            else:
                # Regression
                selector = SelectKBest(score_func=f_regression, k=n_features)
            
            X_selected = selector.fit_transform(X, y)
            selected_features = [numeric_columns[i] for i in selector.get_support(indices=True)]
            
            # Keep selected features and all non-numeric columns
            non_numeric_columns = [col for col in processed_data.columns if col not in numeric_columns]
            processed_data = processed_data[selected_features + non_numeric_columns]
            
            self.feature_selectors['supervised'] = selector
            self.preprocessing_steps.append(f"Selected {len(selected_features)} features using supervised selection")
        
        else:
            # Unsupervised feature selection using variance
            from sklearn.feature_selection import VarianceThreshold
            
            selector = VarianceThreshold(threshold=0.01)
            X_selected = selector.fit_transform(processed_data[numeric_columns])
            selected_features = [numeric_columns[i] for i in selector.get_support(indices=True)]
            
            # Keep selected features and all non-numeric columns
            non_numeric_columns = [col for col in processed_data.columns if col not in numeric_columns]
            processed_data = processed_data[selected_features + non_numeric_columns]
            
            self.feature_selectors['variance'] = selector
            self.preprocessing_steps.append(f"Selected {len(selected_features)} features using variance threshold")
        
        return processed_data
    
    def _reduce_dimensionality(self, data: pd.DataFrame, target_column: Optional[str] = None) -> pd.DataFrame:
        """Perform dimensionality reduction."""
        processed_data = data.copy()
        
        # Get numeric columns for dimensionality reduction
        numeric_columns = [col for col in self.column_types['numeric'] if col in processed_data.columns]
        
        if len(numeric_columns) < 2:
            return processed_data
        
        # Determine number of components
        n_components = min(10, len(numeric_columns), len(processed_data) // 10)
        
        # Apply PCA
        pca = PCA(n_components=n_components)
        X_pca = pca.fit_transform(processed_data[numeric_columns])
        
        # Create DataFrame with PCA components
        pca_columns = [f"PC_{i+1}" for i in range(n_components)]
        pca_df = pd.DataFrame(X_pca, columns=pca_columns, index=processed_data.index)
        
        # Keep non-numeric columns and PCA components
        non_numeric_columns = [col for col in processed_data.columns if col not in numeric_columns]
        processed_data = pd.concat([processed_data[non_numeric_columns], pca_df], axis=1)
        
        self.dimensionality_reducers['pca'] = pca
        self.preprocessing_steps.append(f"Applied PCA, reduced to {n_components} components")
        
        return processed_data
    
    def get_preprocessing_summary(self) -> Dict[str, Any]:
        """Get summary of preprocessing steps applied."""
        return {
            'steps': self.preprocessing_steps,
            'original_shape': self.data.shape if self.data is not None else None,
            'processed_shape': self.processed_data.shape if self.processed_data is not None else None,
            'encoders_applied': list(self.encoders.keys()),
            'scalers_applied': list(self.scalers.keys()),
            'feature_selectors_applied': list(self.feature_selectors.keys()),
            'dimensionality_reducers_applied': list(self.dimensionality_reducers.keys())
        }
    
    def inverse_transform(self, data: pd.DataFrame) -> pd.DataFrame:
        """Apply inverse transformations to get back to original scale."""
        if self.processed_data is None:
            raise ValueError("No preprocessing has been performed yet.")
        
        # This is a simplified inverse transform
        # In practice, you'd need to carefully track the order of transformations
        # and apply inverse transformations in reverse order
        
        inverse_data = data.copy()
        
        # Inverse scale
        if 'standard' in self.scalers:
            numeric_columns = [col for col in self.column_types['numeric'] if col in inverse_data.columns]
            if numeric_columns:
                inverse_data[numeric_columns] = self.scalers['standard'].inverse_transform(inverse_data[numeric_columns])
        
        return inverse_data

