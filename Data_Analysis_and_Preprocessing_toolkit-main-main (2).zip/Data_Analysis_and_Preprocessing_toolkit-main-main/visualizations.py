"""
Comprehensive visualization module for data analysis.
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import stats
from scipy.stats import normaltest, shapiro, kstest
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
from eda_plots import AdvancedEDAPlots
import warnings
warnings.filterwarnings('ignore')

# Set style
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")


class DataVisualizer:
    """Comprehensive data visualization class."""
    
    def __init__(self, figsize: Tuple[int, int] = (12, 8)):
        self.figsize = figsize
        self.colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', 
                      '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']
        self.advanced_plots = AdvancedEDAPlots(figsize)
        
    def create_comprehensive_eda(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create comprehensive EDA visualizations including univariate and multivariate analysis."""
        plots = {}
        
        # 1. Dataset Overview
        plots.update(self._create_dataset_overview_plots(data, analysis_results))
        
        # 2. Univariate Analysis
        plots.update(self._create_univariate_analysis_plots(data, analysis_results))
        
        # 3. Multivariate Analysis
        plots.update(self._create_multivariate_analysis_plots(data, analysis_results))
        
        # 4. Advanced Statistical Plots
        plots.update(self._create_advanced_statistical_plots(data, analysis_results))
        
        # 5. Data Quality Assessment
        plots.update(self._create_data_quality_plots(data, analysis_results))
        
        return plots
    
    def create_overview_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create overview visualization plots."""
        plots = {}
        
        # Dataset overview
        plots['overview'] = self._plot_dataset_overview(data, analysis_results)
        
        # Missing values heatmap
        plots['missing_heatmap'] = self._plot_missing_heatmap(data)
        
        # Data types distribution
        plots['data_types'] = self._plot_data_types(data)
        
        return plots
    
    def create_distribution_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create distribution visualization plots."""
        plots = {}
        
        # Numeric distributions
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            plots['numeric_distributions'] = self._plot_numeric_distributions(data, numeric_cols)
            plots['numeric_boxplots'] = self._plot_numeric_boxplots(data, numeric_cols)
        
        # Categorical distributions
        categorical_cols = data.select_dtypes(include=['object', 'category']).columns
        if len(categorical_cols) > 0:
            plots['categorical_distributions'] = self._plot_categorical_distributions(data, categorical_cols)
        
        return plots
    
    def create_correlation_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create correlation visualization plots."""
        plots = {}
        
        numeric_data = data.select_dtypes(include=[np.number])
        if len(numeric_data.columns) > 1:
            plots['correlation_heatmap'] = self._plot_correlation_heatmap(numeric_data)
            plots['correlation_scatter'] = self._plot_correlation_scatter(numeric_data)
        
        return plots
    
    def create_outlier_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create outlier visualization plots."""
        plots = {}
        
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            plots['outlier_boxplots'] = self._plot_outlier_boxplots(data, numeric_cols)
            plots['outlier_scatter'] = self._plot_outlier_scatter(data, numeric_cols)
        
        return plots
    
    def create_preprocessing_plots(self, original_data: pd.DataFrame, processed_data: pd.DataFrame) -> Dict[str, plt.Figure]:
        """Create preprocessing comparison plots."""
        plots = {}
        
        # Compare shapes
        plots['shape_comparison'] = self._plot_shape_comparison(original_data, processed_data)
        
        # Compare distributions before and after scaling
        numeric_cols = original_data.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            plots['scaling_comparison'] = self._plot_scaling_comparison(original_data, processed_data, numeric_cols)
        
        return plots
    
    def _plot_dataset_overview(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> plt.Figure:
        """Plot dataset overview information."""
        fig, axes = plt.subplots(2, 2, figsize=self.figsize)
        fig.suptitle('Dataset Overview', fontsize=16, fontweight='bold')
        
        # Basic info
        overview = analysis_results['dataset_overview']
        info_text = f"""
        Rows: {overview['shape'][0]:,}
        Columns: {overview['shape'][1]}
        Missing: {overview['missing_percentage']:.2f}%
        Duplicates: {overview['duplicate_percentage']:.2f}%
        Memory: {overview['memory_usage'] / 1024**2:.2f} MB
        """
        axes[0, 0].text(0.1, 0.5, info_text, fontsize=12, verticalalignment='center')
        axes[0, 0].set_title('Basic Information')
        axes[0, 0].axis('off')
        
        # Column types
        column_types = overview['column_types']
        axes[0, 1].pie(column_types.values(), labels=column_types.keys(), autopct='%1.1f%%')
        axes[0, 1].set_title('Column Types Distribution')
        
        # Missing values by column
        missing_data = analysis_results['missing_values']['by_column']
        missing_df = pd.DataFrame(list(missing_data.values()))
        missing_df = missing_df[missing_df['percentage'] > 0].sort_values('percentage', ascending=True)
        
        if not missing_df.empty:
            axes[1, 0].barh(missing_df.index, missing_df['percentage'])
            axes[1, 0].set_xlabel('Missing Percentage')
            axes[1, 0].set_title('Missing Values by Column')
        else:
            axes[1, 0].text(0.5, 0.5, 'No Missing Values', ha='center', va='center')
            axes[1, 0].set_title('Missing Values by Column')
        
        # Data quality score
        quality_score = analysis_results['data_quality']['quality_score']
        axes[1, 1].bar(['Data Quality'], [quality_score], color=self.colors[0])
        axes[1, 1].set_ylim(0, 100)
        axes[1, 1].set_ylabel('Quality Score')
        axes[1, 1].set_title('Data Quality Score')
        
        plt.tight_layout()
        return fig
    
    def _plot_missing_heatmap(self, data: pd.DataFrame) -> plt.Figure:
        """Plot missing values heatmap."""
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Sample data if too large
        if len(data) > 1000:
            sample_data = data.sample(1000)
        else:
            sample_data = data
        
        # Create missing data matrix
        missing_matrix = sample_data.isnull()
        
        # Plot heatmap
        sns.heatmap(missing_matrix.T, cbar=True, yticklabels=True, 
                   xticklabels=False, cmap='viridis', ax=ax)
        ax.set_title('Missing Values Pattern (Sample)')
        ax.set_xlabel('Row Index')
        ax.set_ylabel('Columns')
        
        plt.tight_layout()
        return fig
    
    def _plot_data_types(self, data: pd.DataFrame) -> plt.Figure:
        """Plot data types distribution."""
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Count data types
        dtype_counts = data.dtypes.value_counts()
        
        # Create bar plot
        bars = ax.bar(range(len(dtype_counts)), dtype_counts.values, color=self.colors[:len(dtype_counts)])
        ax.set_xticks(range(len(dtype_counts)))
        ax.set_xticklabels([str(dtype) for dtype in dtype_counts.index], rotation=45)
        ax.set_ylabel('Count')
        ax.set_title('Data Types Distribution')
        
        # Add value labels on bars
        for bar, count in zip(bars, dtype_counts.values):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
                   str(count), ha='center', va='bottom')
        
        plt.tight_layout()
        return fig
    
    def _plot_numeric_distributions(self, data: pd.DataFrame, numeric_cols: List[str]) -> plt.Figure:
        """Plot distributions of numeric columns."""
        n_cols = min(4, len(numeric_cols))
        n_rows = (len(numeric_cols) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 4, n_rows * 3))
        if n_rows == 1:
            axes = [axes] if n_cols == 1 else axes
        else:
            axes = axes.flatten()
        
        for i, col in enumerate(numeric_cols):
            if i < len(axes):
                # Histogram
                axes[i].hist(data[col].dropna(), bins=30, alpha=0.7, color=self.colors[i % len(self.colors)])
                axes[i].set_title(f'Distribution of {col}')
                axes[i].set_xlabel(col)
                axes[i].set_ylabel('Frequency')
                
                # Add statistics
                mean_val = data[col].mean()
                median_val = data[col].median()
                axes[i].axvline(mean_val, color='red', linestyle='--', alpha=0.7, label=f'Mean: {mean_val:.2f}')
                axes[i].axvline(median_val, color='green', linestyle='--', alpha=0.7, label=f'Median: {median_val:.2f}')
                axes[i].legend()
        
        # Hide empty subplots
        for i in range(len(numeric_cols), len(axes)):
            axes[i].set_visible(False)
        
        plt.suptitle('Numeric Distributions', fontsize=16, fontweight='bold')
        plt.tight_layout()
        return fig
    
    def _plot_numeric_boxplots(self, data: pd.DataFrame, numeric_cols: List[str]) -> plt.Figure:
        """Plot boxplots for numeric columns."""
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Prepare data for boxplot
        box_data = [data[col].dropna() for col in numeric_cols]
        
        # Create boxplot
        bp = ax.boxplot(box_data, labels=numeric_cols, patch_artist=True)
        
        # Color the boxes
        for patch, color in zip(bp['boxes'], self.colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        
        ax.set_title('Numeric Columns Boxplots')
        ax.set_ylabel('Value')
        ax.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        return fig
    
    def _plot_categorical_distributions(self, data: pd.DataFrame, categorical_cols: List[str]) -> plt.Figure:
        """Plot distributions of categorical columns."""
        n_cols = min(3, len(categorical_cols))
        n_rows = (len(categorical_cols) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 5, n_rows * 4))
        if n_rows == 1:
            axes = [axes] if n_cols == 1 else axes
        else:
            axes = axes.flatten()
        
        for i, col in enumerate(categorical_cols):
            if i < len(axes):
                # Get value counts
                value_counts = data[col].value_counts().head(10)  # Top 10 values
                
                # Create bar plot
                bars = axes[i].bar(range(len(value_counts)), value_counts.values, 
                                 color=self.colors[:len(value_counts)])
                axes[i].set_xticks(range(len(value_counts)))
                axes[i].set_xticklabels(value_counts.index, rotation=45, ha='right')
                axes[i].set_title(f'Distribution of {col}')
                axes[i].set_ylabel('Count')
                
                # Add value labels on bars
                for bar, count in zip(bars, value_counts.values):
                    axes[i].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
                               str(count), ha='center', va='bottom')
        
        # Hide empty subplots
        for i in range(len(categorical_cols), len(axes)):
            axes[i].set_visible(False)
        
        plt.suptitle('Categorical Distributions', fontsize=16, fontweight='bold')
        plt.tight_layout()
        return fig
    
    def _plot_correlation_heatmap(self, numeric_data: pd.DataFrame) -> plt.Figure:
        """Plot correlation heatmap."""
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Calculate correlation matrix
        corr_matrix = numeric_data.corr()
        
        # Create heatmap
        mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
        sns.heatmap(corr_matrix, mask=mask, annot=True, cmap='coolwarm', center=0,
                   square=True, linewidths=0.5, cbar_kws={"shrink": 0.8}, ax=ax)
        
        ax.set_title('Correlation Heatmap')
        
        plt.tight_layout()
        return fig
    
    def _plot_correlation_scatter(self, numeric_data: pd.DataFrame) -> plt.Figure:
        """Plot correlation scatter matrix."""
        # Select a subset of columns if too many
        if len(numeric_data.columns) > 6:
            numeric_data = numeric_data.iloc[:, :6]
        
        fig = plt.figure(figsize=self.figsize)
        
        # Create scatter matrix
        pd.plotting.scatter_matrix(numeric_data, alpha=0.6, figsize=self.figsize, diagonal='hist')
        
        plt.suptitle('Correlation Scatter Matrix', fontsize=16, fontweight='bold')
        plt.tight_layout()
        return fig
    
    def _plot_outlier_boxplots(self, data: pd.DataFrame, numeric_cols: List[str]) -> plt.Figure:
        """Plot boxplots highlighting outliers."""
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Prepare data for boxplot
        box_data = [data[col].dropna() for col in numeric_cols]
        
        # Create boxplot
        bp = ax.boxplot(box_data, labels=numeric_cols, patch_artist=True)
        
        # Color the boxes
        for patch, color in zip(bp['boxes'], self.colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        
        ax.set_title('Outlier Detection - Boxplots')
        ax.set_ylabel('Value')
        ax.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        return fig
    
    def _plot_outlier_scatter(self, data: pd.DataFrame, numeric_cols: List[str]) -> plt.Figure:
        """Plot scatter plots for outlier detection."""
        if len(numeric_cols) < 2:
            return None
        
        fig, axes = plt.subplots(1, 2, figsize=self.figsize)
        
        # First two numeric columns
        col1, col2 = numeric_cols[0], numeric_cols[1]
        
        # Scatter plot
        axes[0].scatter(data[col1], data[col2], alpha=0.6, color=self.colors[0])
        axes[0].set_xlabel(col1)
        axes[0].set_ylabel(col2)
        axes[0].set_title(f'Scatter Plot: {col1} vs {col2}')
        
        # Add outlier detection using IQR
        Q1_1, Q3_1 = data[col1].quantile([0.25, 0.75])
        Q1_2, Q3_2 = data[col2].quantile([0.25, 0.75])
        IQR_1, IQR_2 = Q3_1 - Q1_1, Q3_2 - Q1_2
        
        outliers_1 = (data[col1] < Q1_1 - 1.5 * IQR_1) | (data[col1] > Q3_1 + 1.5 * IQR_1)
        outliers_2 = (data[col2] < Q1_2 - 1.5 * IQR_2) | (data[col2] > Q3_2 + 1.5 * IQR_2)
        outliers = outliers_1 | outliers_2
        
        # Highlight outliers
        axes[1].scatter(data[~outliers][col1], data[~outliers][col2], 
                       alpha=0.6, color=self.colors[0], label='Normal')
        axes[1].scatter(data[outliers][col1], data[outliers][col2], 
                       alpha=0.8, color='red', label='Outliers')
        axes[1].set_xlabel(col1)
        axes[1].set_ylabel(col2)
        axes[1].set_title(f'Outlier Detection: {col1} vs {col2}')
        axes[1].legend()
        
        plt.tight_layout()
        return fig
    
    def _plot_shape_comparison(self, original_data: pd.DataFrame, processed_data: pd.DataFrame) -> plt.Figure:
        """Plot shape comparison before and after preprocessing."""
        fig, axes = plt.subplots(1, 2, figsize=self.figsize)
        
        # Shape comparison
        shapes = ['Original', 'Processed']
        rows = [original_data.shape[0], processed_data.shape[0]]
        cols = [original_data.shape[1], processed_data.shape[1]]
        
        x = np.arange(len(shapes))
        width = 0.35
        
        axes[0].bar(x - width/2, rows, width, label='Rows', color=self.colors[0])
        axes[0].bar(x + width/2, cols, width, label='Columns', color=self.colors[1])
        axes[0].set_xlabel('Dataset')
        axes[0].set_ylabel('Count')
        axes[0].set_title('Shape Comparison')
        axes[0].set_xticks(x)
        axes[0].set_xticklabels(shapes)
        axes[0].legend()
        
        # Add value labels
        for i, (r, c) in enumerate(zip(rows, cols)):
            axes[0].text(i - width/2, r + max(rows) * 0.01, str(r), ha='center', va='bottom')
            axes[0].text(i + width/2, c + max(cols) * 0.01, str(c), ha='center', va='bottom')
        
        # Memory usage comparison
        original_memory = original_data.memory_usage(deep=True).sum() / 1024**2
        processed_memory = processed_data.memory_usage(deep=True).sum() / 1024**2
        
        axes[1].bar(shapes, [original_memory, processed_memory], color=self.colors[:2])
        axes[1].set_ylabel('Memory Usage (MB)')
        axes[1].set_title('Memory Usage Comparison')
        
        # Add value labels
        for i, mem in enumerate([original_memory, processed_memory]):
            axes[1].text(i, mem + max(original_memory, processed_memory) * 0.01, 
                        f'{mem:.2f} MB', ha='center', va='bottom')
        
        plt.tight_layout()
        return fig
    
    def _plot_scaling_comparison(self, original_data: pd.DataFrame, processed_data: pd.DataFrame, 
                                numeric_cols: List[str]) -> plt.Figure:
        """Plot scaling comparison before and after preprocessing."""
        if len(numeric_cols) == 0:
            return None
        
        # Select first few numeric columns for comparison
        cols_to_plot = numeric_cols[:4]
        
        fig, axes = plt.subplots(2, 2, figsize=self.figsize)
        axes = axes.flatten()
        
        for i, col in enumerate(cols_to_plot):
            if i < len(axes) and col in processed_data.columns:
                # Plot original distribution
                axes[i].hist(original_data[col].dropna(), bins=30, alpha=0.7, 
                           color=self.colors[0], label='Original', density=True)
                
                # Plot processed distribution
                axes[i].hist(processed_data[col].dropna(), bins=30, alpha=0.7, 
                           color=self.colors[1], label='Processed', density=True)
                
                axes[i].set_title(f'Scaling: {col}')
                axes[i].set_xlabel(col)
                axes[i].set_ylabel('Density')
                axes[i].legend()
        
        # Hide empty subplots
        for i in range(len(cols_to_plot), len(axes)):
            axes[i].set_visible(False)
        
        plt.suptitle('Scaling Comparison', fontsize=16, fontweight='bold')
        plt.tight_layout()
        return fig
    
    def create_interactive_plots(self, data: pd.DataFrame) -> Dict[str, go.Figure]:
        """Create interactive plots using Plotly."""
        plots = {}
        
        # Interactive correlation heatmap
        numeric_data = data.select_dtypes(include=[np.number])
        if len(numeric_data.columns) > 1:
            corr_matrix = numeric_data.corr()
            plots['interactive_correlation'] = px.imshow(
                corr_matrix, 
                text_auto=True, 
                aspect="auto",
                title="Interactive Correlation Heatmap"
            )
        
        # Interactive scatter plot
        if len(numeric_data.columns) >= 2:
            plots['interactive_scatter'] = px.scatter(
                data, 
                x=numeric_data.columns[0], 
                y=numeric_data.columns[1],
                title=f"Interactive Scatter: {numeric_data.columns[0]} vs {numeric_data.columns[1]}"
            )
        
        return plots
    
    def save_plots(self, plots: Dict[str, plt.Figure], output_dir: str = "plots"):
        """Save all plots to files."""
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        for name, fig in plots.items():
            if fig is not None:
                fig.savefig(f"{output_dir}/{name}.png", dpi=300, bbox_inches='tight')
                plt.close(fig)
        
        print(f"Plots saved to {output_dir}/")
    
    # ==================== COMPREHENSIVE EDA METHODS ====================
    
    def _create_dataset_overview_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create dataset overview plots."""
        plots = {}
        
        # Basic dataset overview
        plots['dataset_overview'] = self._plot_dataset_overview(data, analysis_results)
        
        # Missing values analysis
        plots['missing_values_analysis'] = self._plot_missing_values_analysis(data, analysis_results)
        
        # Data types distribution
        plots['data_types_distribution'] = self._plot_data_types(data)
        
        # Memory usage analysis
        plots['memory_usage_analysis'] = self._plot_memory_usage_analysis(data)
        
        return plots
    
    def _create_univariate_analysis_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create univariate analysis plots."""
        plots = {}
        
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        categorical_cols = data.select_dtypes(include=['object', 'category']).columns
        
        # Numeric univariate analysis
        if len(numeric_cols) > 0:
            plots['numeric_univariate'] = self._plot_numeric_univariate_analysis(data, numeric_cols)
            plots['numeric_distributions'] = self._plot_numeric_distributions(data, numeric_cols)
            plots['numeric_boxplots'] = self._plot_numeric_boxplots(data, numeric_cols)
            plots['numeric_qq_plots'] = self._plot_qq_plots(data, numeric_cols)
            plots['numeric_histograms_with_stats'] = self._plot_histograms_with_statistics(data, numeric_cols)
        
        # Categorical univariate analysis
        if len(categorical_cols) > 0:
            plots['categorical_univariate'] = self._plot_categorical_univariate_analysis(data, categorical_cols)
            plots['categorical_distributions'] = self._plot_categorical_distributions(data, categorical_cols)
            plots['categorical_pie_charts'] = self._plot_categorical_pie_charts(data, categorical_cols)
        
        return plots
    
    def _create_multivariate_analysis_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create multivariate analysis plots."""
        plots = {}
        
        numeric_data = data.select_dtypes(include=[np.number])
        
        if len(numeric_data.columns) > 1:
            # Correlation analysis
            plots['correlation_matrix'] = self._plot_correlation_matrix(numeric_data)
            plots['correlation_heatmap'] = self._plot_correlation_heatmap(numeric_data)
            plots['correlation_scatter_matrix'] = self._plot_correlation_scatter_matrix(numeric_data)
            
            # Pairwise relationships
            plots['pairwise_relationships'] = self._plot_pairwise_relationships(data, numeric_data.columns)
            
            # Principal Component Analysis
            plots['pca_analysis'] = self._plot_pca_analysis(numeric_data)
            
            # Clustering analysis
            plots['clustering_analysis'] = self._plot_clustering_analysis(numeric_data)
        
        # Mixed data type analysis
        plots['mixed_data_analysis'] = self._plot_mixed_data_analysis(data)
        
        return plots
    
    def _create_advanced_statistical_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create advanced statistical plots."""
        plots = {}
        
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        
        if len(numeric_cols) > 0:
            # Distribution fitting
            plots['distribution_fitting'] = self._plot_distribution_fitting(data, numeric_cols)
            
            # Normality tests
            plots['normality_tests'] = self._plot_normality_tests(data, numeric_cols)
            
            # Outlier analysis
            plots['outlier_analysis'] = self._plot_outlier_analysis(data, numeric_cols)
            
            # Time series analysis (if applicable)
            plots['time_series_analysis'] = self._plot_time_series_analysis(data, numeric_cols)
        
        return plots
    
    def _create_data_quality_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create data quality assessment plots."""
        plots = {}
        
        # Data completeness
        plots['data_completeness'] = self._plot_data_completeness(data)
        
        # Duplicate analysis
        plots['duplicate_analysis'] = self._plot_duplicate_analysis(data)
        
        # Data consistency
        plots['data_consistency'] = self._plot_data_consistency(data)
        
        # Quality score visualization
        plots['quality_score_visualization'] = self._plot_quality_score_visualization(analysis_results)
        
        return plots

