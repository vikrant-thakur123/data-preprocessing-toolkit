"""
ML-Focused EDA module for streamlined analysis optimized for machine learning insights.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Any, Optional
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_regression, f_classif
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score, classification_report
import warnings
warnings.filterwarnings('ignore')


class MLFocusedEDA:
    """ML-Focused EDA for streamlined analysis optimized for machine learning insights."""
    
    def __init__(self, figsize: tuple = (12, 8)):
        self.figsize = figsize
        self.colors = ['#00d4aa', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57', '#ff9ff3', '#54a0ff']
        
    def create_ml_eda_plots(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Create ML-focused EDA plots."""
        plots = {}
        
        # 1. Target variable analysis (if available)
        plots.update(self._plot_target_analysis(data, analysis_results))
        
        # 2. Feature importance analysis
        plots.update(self._plot_feature_importance(data, analysis_results))
        
        # 3. Correlation heatmap for ML features
        plots.update(self._plot_ml_correlation_heatmap(data, analysis_results))
        
        # 4. Feature distribution for ML
        plots.update(self._plot_ml_feature_distributions(data, analysis_results))
        
        # 5. Outlier analysis for ML
        plots.update(self._plot_ml_outlier_analysis(data, analysis_results))
        
        # 6. Data quality for ML
        plots.update(self._plot_ml_data_quality(data, analysis_results))
        
        return plots
    
    def generate_ml_insights(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> List[str]:
        """Generate ML-focused insights and recommendations."""
        insights = []
        
        # Dataset readiness for ML
        shape = analysis_results['dataset_overview']['shape']
        insights.append(f"Dataset contains {shape[0]:,} samples and {shape[1]} features - suitable for ML training")
        
        # Missing data impact on ML
        missing_pct = analysis_results['dataset_overview']['missing_percentage']
        if missing_pct > 10:
            insights.append(f"⚠️ High missing data ({missing_pct:.1f}%) may impact ML model performance - consider advanced imputation")
        elif missing_pct > 0:
            insights.append(f"✅ Low missing data ({missing_pct:.1f}%) - standard imputation should work well for ML")
        else:
            insights.append("✅ No missing values - perfect for ML model training")
        
        # Data quality for ML
        quality_score = analysis_results['data_quality']['quality_score']
        if quality_score >= 80:
            insights.append("✅ High data quality score - dataset is ready for ML model training")
        elif quality_score >= 60:
            insights.append("⚠️ Moderate data quality - consider additional cleaning before ML training")
        else:
            insights.append("❌ Low data quality - significant data cleaning required before ML training")
        
        # Feature count recommendations
        numeric_cols = analysis_results['dataset_overview']['column_types']['numeric']
        if numeric_cols > 50:
            insights.append("🔍 High dimensionality detected - consider feature selection or dimensionality reduction for ML")
        elif numeric_cols > 20:
            insights.append("⚠️ Moderate dimensionality - feature selection may improve ML model performance")
        else:
            insights.append("✅ Good feature count for ML model training")
        
        # Outlier impact on ML
        total_outliers = sum(
            col_outliers['iqr_outliers']['count'] 
            for col_outliers in analysis_results['outliers'].values()
        )
        if total_outliers > shape[0] * 0.1:
            insights.append("⚠️ High outlier count may impact ML model performance - consider outlier treatment")
        elif total_outliers > 0:
            insights.append("✅ Moderate outlier count - monitor impact on ML model performance")
        else:
            insights.append("✅ No outliers detected - clean data for ML training")
        
        # Correlation insights for ML
        if 'high_correlations' in analysis_results['correlations']:
            high_corr = analysis_results['correlations']['high_correlations']
            if high_corr:
                insights.append(f"🔍 {len(high_corr)} highly correlated feature pairs detected - consider removing redundant features for ML")
        
        # Sample size recommendations
        if shape[0] < 100:
            insights.append("⚠️ Small dataset - consider data augmentation or simpler ML models")
        elif shape[0] < 1000:
            insights.append("✅ Medium dataset size - suitable for most ML algorithms")
        else:
            insights.append("✅ Large dataset - excellent for complex ML models and deep learning")
        
        return insights
    
    def _plot_target_analysis(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Plot target variable analysis for ML."""
        plots = {}
        
        # Try to identify potential target variables
        numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
        
        if len(numeric_cols) > 0:
            # Use the last numeric column as potential target (common convention)
            target_col = numeric_cols[-1]
            
            fig, axes = plt.subplots(2, 2, figsize=self.figsize)
            fig.suptitle(f'Target Variable Analysis: {target_col}', fontsize=16, fontweight='bold')
            
            # Distribution
            axes[0, 0].hist(data[target_col].dropna(), bins=30, alpha=0.7, color=self.colors[0])
            axes[0, 0].set_title('Distribution')
            axes[0, 0].set_xlabel(target_col)
            axes[0, 0].set_ylabel('Frequency')
            
            # Box plot
            axes[0, 1].boxplot(data[target_col].dropna())
            axes[0, 1].set_title('Box Plot')
            axes[0, 1].set_ylabel(target_col)
            
            # Q-Q plot
            from scipy import stats
            stats.probplot(data[target_col].dropna(), dist="norm", plot=axes[1, 0])
            axes[1, 0].set_title('Q-Q Plot (Normality Check)')
            
            # Time series (if index suggests time)
            axes[1, 1].plot(data[target_col].values)
            axes[1, 1].set_title('Value Progression')
            axes[1, 1].set_xlabel('Index')
            axes[1, 1].set_ylabel(target_col)
            
            plt.tight_layout()
            plots['target_analysis'] = fig
        
        return plots
    
    def _plot_feature_importance(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Plot feature importance analysis for ML."""
        plots = {}
        
        numeric_data = data.select_dtypes(include=[np.number])
        
        if len(numeric_data.columns) > 1:
            # Use the last column as target for feature importance
            target_col = numeric_data.columns[-1]
            feature_cols = numeric_data.columns[:-1]
            
            if len(feature_cols) > 0:
                X = numeric_data[feature_cols].fillna(numeric_data[feature_cols].mean())
                y = numeric_data[target_col].fillna(numeric_data[target_col].mean())
                
                # Random Forest feature importance
                rf = RandomForestRegressor(n_estimators=100, random_state=42)
                rf.fit(X, y)
                
                # Get feature importance
                importance = rf.feature_importances_
                feature_names = feature_cols
                
                # Sort by importance
                indices = np.argsort(importance)[::-1]
                
                fig, ax = plt.subplots(figsize=self.figsize)
                ax.barh(range(len(feature_names)), importance[indices], color=self.colors[0])
                ax.set_yticks(range(len(feature_names)))
                ax.set_yticklabels([feature_names[i] for i in indices])
                ax.set_xlabel('Feature Importance')
                ax.set_title('Feature Importance for ML (Random Forest)')
                ax.invert_yaxis()
                
                plt.tight_layout()
                plots['feature_importance'] = fig
        
        return plots
    
    def _plot_ml_correlation_heatmap(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Plot ML-focused correlation heatmap."""
        plots = {}
        
        numeric_data = data.select_dtypes(include=[np.number])
        
        if len(numeric_data.columns) > 1:
            fig, ax = plt.subplots(figsize=self.figsize)
            
            # Calculate correlation matrix
            corr_matrix = numeric_data.corr()
            
            # Create heatmap
            mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
            sns.heatmap(corr_matrix, mask=mask, annot=True, cmap='RdYlBu_r', center=0,
                       square=True, linewidths=0.5, cbar_kws={"shrink": 0.8}, ax=ax)
            
            ax.set_title('Feature Correlation Matrix for ML')
            
            plt.tight_layout()
            plots['ml_correlation_heatmap'] = fig
        
        return plots
    
    def _plot_ml_feature_distributions(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Plot ML-focused feature distributions."""
        plots = {}
        
        numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
        
        if len(numeric_cols) > 0:
            # Select top 6 features for visualization
            n_features = min(6, len(numeric_cols))
            selected_cols = numeric_cols[:n_features]
            
            n_rows = (n_features + 2) // 3
            n_cols = min(3, n_features)
            
            fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 4, n_rows * 3))
            if n_rows == 1:
                axes = [axes] if n_cols == 1 else axes
            else:
                axes = axes.flatten()
            
            for i, col in enumerate(selected_cols):
                if i < len(axes):
                    # Histogram
                    axes[i].hist(data[col].dropna(), bins=30, alpha=0.7, color=self.colors[i % len(self.colors)])
                    axes[i].set_title(f'{col} Distribution')
                    axes[i].set_xlabel(col)
                    axes[i].set_ylabel('Frequency')
                    
                    # Add statistics
                    mean_val = data[col].mean()
                    std_val = data[col].std()
                    axes[i].axvline(mean_val, color='red', linestyle='--', alpha=0.7, label=f'Mean: {mean_val:.2f}')
                    axes[i].axvline(mean_val + std_val, color='orange', linestyle='--', alpha=0.7, label=f'+1σ')
                    axes[i].axvline(mean_val - std_val, color='orange', linestyle='--', alpha=0.7, label=f'-1σ')
                    axes[i].legend()
            
            # Hide empty subplots
            for i in range(len(selected_cols), len(axes)):
                axes[i].set_visible(False)
            
            plt.suptitle('ML Feature Distributions', fontsize=16, fontweight='bold')
            plt.tight_layout()
            plots['ml_feature_distributions'] = fig
        
        return plots
    
    def _plot_ml_outlier_analysis(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Plot ML-focused outlier analysis."""
        plots = {}
        
        numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
        
        if len(numeric_cols) > 0:
            # Select top 4 features for outlier analysis
            n_features = min(4, len(numeric_cols))
            selected_cols = numeric_cols[:n_features]
            
            fig, axes = plt.subplots(2, 2, figsize=self.figsize)
            axes = axes.flatten()
            
            for i, col in enumerate(selected_cols):
                if i < len(axes):
                    # Box plot with outlier highlighting
                    box_data = data[col].dropna()
                    
                    # Calculate outliers using IQR
                    Q1 = box_data.quantile(0.25)
                    Q3 = box_data.quantile(0.75)
                    IQR = Q3 - Q1
                    lower_bound = Q1 - 1.5 * IQR
                    upper_bound = Q3 + 1.5 * IQR
                    
                    outliers = box_data[(box_data < lower_bound) | (box_data > upper_bound)]
                    
                    # Create box plot
                    bp = axes[i].boxplot([box_data], labels=[col], patch_artist=True)
                    bp['boxes'][0].set_facecolor(self.colors[i % len(self.colors)])
                    bp['boxes'][0].set_alpha(0.7)
                    
                    axes[i].set_title(f'{col} Outliers: {len(outliers)}')
                    axes[i].set_ylabel(col)
            
            # Hide empty subplots
            for i in range(len(selected_cols), len(axes)):
                axes[i].set_visible(False)
            
            plt.suptitle('ML Feature Outlier Analysis', fontsize=16, fontweight='bold')
            plt.tight_layout()
            plots['ml_outlier_analysis'] = fig
        
        return plots
    
    def _plot_ml_data_quality(self, data: pd.DataFrame, analysis_results: Dict[str, Any]) -> Dict[str, plt.Figure]:
        """Plot ML-focused data quality assessment."""
        plots = {}
        
        fig, axes = plt.subplots(2, 2, figsize=self.figsize)
        fig.suptitle('ML Data Quality Assessment', fontsize=16, fontweight='bold')
        
        # Missing values by column
        missing_data = data.isnull().sum()
        missing_data = missing_data[missing_data > 0].sort_values(ascending=True)
        
        if not missing_data.empty:
            axes[0, 0].barh(missing_data.index, missing_data.values, color=self.colors[0])
            axes[0, 0].set_title('Missing Values by Column')
            axes[0, 0].set_xlabel('Missing Count')
        else:
            axes[0, 0].text(0.5, 0.5, 'No Missing Values', ha='center', va='center', transform=axes[0, 0].transAxes)
            axes[0, 0].set_title('Missing Values by Column')
        
        # Data types distribution
        dtype_counts = data.dtypes.value_counts()
        axes[0, 1].pie(dtype_counts.values, labels=dtype_counts.index, autopct='%1.1f%%', colors=self.colors)
        axes[0, 1].set_title('Data Types Distribution')
        
        # Data quality score
        quality_score = analysis_results['data_quality']['quality_score']
        axes[1, 0].bar(['Data Quality'], [quality_score], color=self.colors[1])
        axes[1, 0].set_ylim(0, 100)
        axes[1, 0].set_ylabel('Quality Score')
        axes[1, 0].set_title('Overall Data Quality Score')
        
        # Memory usage
        memory_usage = data.memory_usage(deep=True).sum() / 1024**2
        axes[1, 1].bar(['Memory Usage'], [memory_usage], color=self.colors[2])
        axes[1, 1].set_ylabel('Memory (MB)')
        axes[1, 1].set_title('Dataset Memory Usage')
        
        plt.tight_layout()
        plots['ml_data_quality'] = fig
        
        return plots